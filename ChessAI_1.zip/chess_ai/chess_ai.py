#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ChessAI - Bot cờ vua tất cả trong 1 file
=========================================

  * Luật cờ / sinh nước đi : python-chess (nhập thành, bắt tốt qua đường, phong cấp, chiếu, hết nước)
  * Hàm đánh giá           : vật chất + piece-square tables (tapered mg/eg) + cấu trúc tốt,
                             cặp Tượng, Xe cột mở, an toàn Vua, độ cơ động
                             (+ tùy chọn mạng neural NumPy học từ Hugging Face)
  * Tìm kiếm               : Negamax + Alpha-beta (PVS), Iterative deepening, Quiescence,
                             Transposition table (Zobrist hashing), Move ordering
                             (TT move, MVV-LVA, chiếu, killer, history), Null-move, LMR
  * Opening book           : xây từ ván cờ Lichess trên Hugging Face (Lichess/standard-chess-games)
  * Endgame tablebase      : Syzygy (nếu có thư mục ./syzygy)
  * Giao diện              : Tkinter. F1 = Bắt đầu/Tiếp tục, F2 = Tạm dừng, F3 = Thoát
                             Chỉnh Elo 1300-2500
  * Ảnh chụp               : sau MỖI nước đi (bot hoặc người) chụp lại bàn cờ bằng
                             PIL.ImageGrab -> NumPy -> OpenCV, lưu vào ./screenshots
  * UCI                    : python chess_ai.py --uci  (dùng cho Arena, Cute Chess, lichess-bot)
  * Bot trên màn hình      : tự tìm bàn cờ trên trang web, học hình quân từ thế ban đầu,
                             nhận diện nước của đối thủ bằng OpenCV, tự click chuột (pyautogui)

Chạy:  python chess_ai.py           (giao diện)
       python chess_ai.py --uci     (chế độ engine UCI)
       python chess_ai.py --book 20000      (tạo opening book từ Hugging Face, không cần UI)
       python chess_ai.py --train 200000    (huấn luyện mạng đánh giá từ Hugging Face)
       python chess_ai.py --bench           (đo tốc độ engine)
       python chess_ai.py --match 10 --elo-a 2500 --elo-b 1300   (cho 2 cấu hình đấu nhau)
"""

import os
import sys
import re
import time
import json
import math
import random
import queue
import argparse
import datetime
import threading

try:
    import chess
    import chess.polyglot
    import chess.syzygy
except ImportError:
    print("Thiếu thư viện python-chess. Cài bằng:  pip install chess")
    sys.exit(1)

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None


# ============================================================================
# Đường dẫn & hằng số
# ============================================================================
APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(APP_DIR, "data")
BOOK_PATH = os.path.join(DATA_DIR, "opening_book.json")
NN_PATH = os.path.join(DATA_DIR, "nn_eval.npz")
SHOT_DIR = os.path.join(APP_DIR, "screenshots")
SYZYGY_DIR = os.path.join(APP_DIR, "syzygy")

HF_GAMES_DATASET = "Lichess/standard-chess-games"        # cột: WhiteElo, BlackElo, movetext, ...
HF_EVAL_DATASET = "Lichess/chess-position-evaluations"   # cột: fen, line, depth, knodes, cp, mate

ELO_MIN, ELO_MAX = 1300, 2500

INF = 10 ** 7
MATE = 100_000
MATE_BOUND = MATE - 1000

PIECE_VALUE = {chess.PAWN: 100, chess.KNIGHT: 320, chess.BISHOP: 330,
               chess.ROOK: 500, chess.QUEEN: 900, chess.KING: 0}


def log_print(*a):
    print(*a, file=sys.stderr, flush=True)


# ============================================================================
# 2. HÀM ĐÁNH GIÁ
# ============================================================================
# Piece-square tables, viết theo góc nhìn quân Trắng, hàng 8 ở trên cùng (a8 = chỉ số 0).
# Nguồn ý tưởng: "Simplified Evaluation Function" (Tomasz Michniewski).
_PST_PAWN = [
    0, 0, 0, 0, 0, 0, 0, 0,
    50, 50, 50, 50, 50, 50, 50, 50,
    10, 10, 20, 30, 30, 20, 10, 10,
    5, 5, 10, 25, 25, 10, 5, 5,
    0, 0, 0, 20, 20, 0, 0, 0,
    5, -5, -10, 0, 0, -10, -5, 5,
    5, 10, 10, -20, -20, 10, 10, 5,
    0, 0, 0, 0, 0, 0, 0, 0]
_PST_KNIGHT = [
    -50, -40, -30, -30, -30, -30, -40, -50,
    -40, -20, 0, 0, 0, 0, -20, -40,
    -30, 0, 10, 15, 15, 10, 0, -30,
    -30, 5, 15, 20, 20, 15, 5, -30,
    -30, 0, 15, 20, 20, 15, 0, -30,
    -30, 5, 10, 15, 15, 10, 5, -30,
    -40, -20, 0, 5, 5, 0, -20, -40,
    -50, -40, -30, -30, -30, -30, -40, -50]
_PST_BISHOP = [
    -20, -10, -10, -10, -10, -10, -10, -20,
    -10, 0, 0, 0, 0, 0, 0, -10,
    -10, 0, 5, 10, 10, 5, 0, -10,
    -10, 5, 5, 10, 10, 5, 5, -10,
    -10, 0, 10, 10, 10, 10, 0, -10,
    -10, 10, 10, 10, 10, 10, 10, -10,
    -10, 5, 0, 0, 0, 0, 5, -10,
    -20, -10, -10, -10, -10, -10, -10, -20]
_PST_ROOK = [
    0, 0, 0, 0, 0, 0, 0, 0,
    5, 10, 10, 10, 10, 10, 10, 5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    -5, 0, 0, 0, 0, 0, 0, -5,
    0, 0, 0, 5, 5, 0, 0, 0]
_PST_QUEEN = [
    -20, -10, -10, -5, -5, -10, -10, -20,
    -10, 0, 0, 0, 0, 0, 0, -10,
    -10, 0, 5, 5, 5, 5, 0, -10,
    -5, 0, 5, 5, 5, 5, 0, -5,
    0, 0, 5, 5, 5, 5, 0, -5,
    -10, 5, 5, 5, 5, 5, 0, -10,
    -10, 0, 5, 0, 0, 0, 0, -10,
    -20, -10, -10, -5, -5, -10, -10, -20]
_PST_KING_MG = [
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -30, -40, -40, -50, -50, -40, -40, -30,
    -20, -30, -30, -40, -40, -30, -30, -20,
    -10, -20, -20, -20, -20, -20, -20, -10,
    20, 20, 0, 0, 0, 0, 20, 20,
    20, 30, 10, 0, 0, 10, 30, 20]
_PST_KING_EG = [
    -50, -40, -30, -20, -20, -30, -40, -50,
    -30, -20, -10, 0, 0, -10, -20, -30,
    -30, -10, 20, 30, 30, 20, -10, -30,
    -30, -10, 30, 40, 40, 30, -10, -30,
    -30, -10, 30, 40, 40, 30, -10, -30,
    -30, -10, 20, 30, 30, 20, -10, -30,
    -30, -30, 0, 0, 0, 0, -30, -30,
    -50, -30, -30, -30, -30, -30, -30, -50]


def _make_tables(table, base):
    """Trả về (bảng cho Trắng, bảng cho Đen) đánh chỉ số theo ô python-chess (a1 = 0)."""
    white = [base + table[sq ^ 56] for sq in range(64)]
    black = [base + table[sq] for sq in range(64)]
    return white, black


PST_W, PST_B = {}, {}
for _pt, _tbl in ((chess.PAWN, _PST_PAWN), (chess.KNIGHT, _PST_KNIGHT), (chess.BISHOP, _PST_BISHOP),
                  (chess.ROOK, _PST_ROOK), (chess.QUEEN, _PST_QUEEN)):
    PST_W[_pt], PST_B[_pt] = _make_tables(_tbl, PIECE_VALUE[_pt])
KMG_W, KMG_B = _make_tables(_PST_KING_MG, 0)
KEG_W, KEG_B = _make_tables(_PST_KING_EG, 0)

PHASE_INC = {chess.KNIGHT: 1, chess.BISHOP: 1, chess.ROOK: 2, chess.QUEEN: 4}
PASSED_BONUS = [0, 5, 10, 20, 35, 60, 100, 0]          # theo hàng (tính từ phía mình)
MOBILITY_W = {chess.KNIGHT: 4, chess.BISHOP: 4, chess.ROOK: 2, chess.QUEEN: 1}

FILE_MASK = [chess.BB_FILES[f] for f in range(8)]
ADJ_FILE_MASK = []
for _f in range(8):
    _m = 0
    if _f > 0:
        _m |= chess.BB_FILES[_f - 1]
    if _f < 7:
        _m |= chess.BB_FILES[_f + 1]
    ADJ_FILE_MASK.append(_m)

# Mặt nạ tốt thông: các ô phía trước trên cùng cột và 2 cột kề
PASSED_MASK_W, PASSED_MASK_B = [0] * 64, [0] * 64
for _sq in range(64):
    _f, _r = chess.square_file(_sq), chess.square_rank(_sq)
    _files = FILE_MASK[_f] | ADJ_FILE_MASK[_f]
    _ahead_w = 0
    for _rr in range(_r + 1, 8):
        _ahead_w |= chess.BB_RANKS[_rr]
    _ahead_b = 0
    for _rr in range(0, _r):
        _ahead_b |= chess.BB_RANKS[_rr]
    PASSED_MASK_W[_sq] = _files & _ahead_w
    PASSED_MASK_B[_sq] = _files & _ahead_b

popcount = chess.popcount
scan = chess.scan_forward


def classic_evaluate(board):
    """Điểm (centipawn) theo góc nhìn bên Trắng."""
    white, black = board.occupied_co[chess.WHITE], board.occupied_co[chess.BLACK]
    score = 0
    phase = 0

    # --- vật chất + vị trí ---
    for pt, bb in ((chess.PAWN, board.pawns), (chess.KNIGHT, board.knights), (chess.BISHOP, board.bishops),
                   (chess.ROOK, board.rooks), (chess.QUEEN, board.queens)):
        tw, tb = PST_W[pt], PST_B[pt]
        for sq in scan(bb & white):
            score += tw[sq]
        for sq in scan(bb & black):
            score -= tb[sq]
        if pt in PHASE_INC:
            phase += PHASE_INC[pt] * popcount(bb)
    phase = min(phase, 24)          # 24 = trung cuộc đầy đủ, 0 = tàn cuộc thuần
    eg_w = 24 - phase

    wk, bk = board.king(chess.WHITE), board.king(chess.BLACK)
    if wk is None or bk is None:
        return 0
    score += ((KMG_W[wk] - KMG_B[bk]) * phase + (KEG_W[wk] - KEG_B[bk]) * eg_w) // 24

    # --- cặp Tượng ---
    if popcount(board.bishops & white) >= 2:
        score += 30
    if popcount(board.bishops & black) >= 2:
        score -= 30

    # --- cấu trúc tốt ---
    wp, bp = board.pawns & white, board.pawns & black
    for f in range(8):
        fm = FILE_MASK[f]
        nw, nb = popcount(wp & fm), popcount(bp & fm)
        if nw > 1:
            score -= 15 * (nw - 1)                        # tốt chồng
        if nb > 1:
            score += 15 * (nb - 1)
        if nw and not (wp & ADJ_FILE_MASK[f]):
            score -= 12 * nw                              # tốt cô lập
        if nb and not (bp & ADJ_FILE_MASK[f]):
            score += 12 * nb
    for sq in scan(wp):
        if not (PASSED_MASK_W[sq] & bp):                  # tốt thông
            r = chess.square_rank(sq)
            score += PASSED_BONUS[r] * (12 + eg_w) // 24
    for sq in scan(bp):
        if not (PASSED_MASK_B[sq] & wp):
            r = 7 - chess.square_rank(sq)
            score -= PASSED_BONUS[r] * (12 + eg_w) // 24

    # --- Xe ở cột mở / nửa mở ---
    for sq in scan(board.rooks & white):
        fm = FILE_MASK[chess.square_file(sq)]
        if not (fm & wp):
            score += 15 if not (fm & bp) else 8
    for sq in scan(board.rooks & black):
        fm = FILE_MASK[chess.square_file(sq)]
        if not (fm & bp):
            score -= 15 if not (fm & wp) else 8

    # --- độ cơ động (số ô kiểm soát không bị quân mình chiếm) ---
    mob = 0
    for pt in (chess.KNIGHT, chess.BISHOP, chess.ROOK, chess.QUEEN):
        bb = board.pieces_mask(pt, chess.WHITE)
        w = MOBILITY_W[pt]
        for sq in scan(bb):
            mob += w * popcount(board.attacks_mask(sq) & ~white)
        bb = board.pieces_mask(pt, chess.BLACK)
        for sq in scan(bb):
            mob -= w * popcount(board.attacks_mask(sq) & ~black)
    score += mob

    # --- an toàn Vua (lá chắn tốt, chỉ có giá trị ở trung cuộc) ---
    if phase > 6:
        shield = 0
        kf, kr = chess.square_file(wk), chess.square_rank(wk)
        if kr <= 1:
            for df in (-1, 0, 1):
                f = kf + df
                if 0 <= f < 8:
                    for rr in (kr + 1, kr + 2):
                        if rr < 8 and wp & chess.BB_SQUARES[chess.square(f, rr)]:
                            shield += 12 if rr == kr + 1 else 6
                            break
        kf, kr = chess.square_file(bk), chess.square_rank(bk)
        if kr >= 6:
            for df in (-1, 0, 1):
                f = kf + df
                if 0 <= f < 8:
                    for rr in (kr - 1, kr - 2):
                        if rr >= 0 and bp & chess.BB_SQUARES[chess.square(f, rr)]:
                            shield -= 12 if rr == kr - 1 else 6
                            break
        score += shield * phase // 24

    # --- lượt đi ---
    score += 10 if board.turn == chess.WHITE else -10
    return score


# ============================================================================
# 6. MẠNG NEURAL ĐÁNH GIÁ (NumPy) - học từ Hugging Face
# ============================================================================
class NNEval:
    """MLP nhỏ 768 -> H -> 1, đầu vào one-hot (12 loại quân x 64 ô), đầu ra tanh(cp/400).

    Vì đầu vào thưa, lớp ẩn được tính bằng cách cộng các hàng của W1 (giống ý tưởng NNUE):
        h = b1 + sum(W1[i] for i in active_features)
    """
    SCALE = 400.0

    def __init__(self, hidden=64, seed=0):
        rng = np.random.default_rng(seed)
        self.W1 = (rng.standard_normal((768, hidden)) * 0.05).astype(np.float32)
        self.b1 = np.zeros(hidden, np.float32)
        self.W2 = (rng.standard_normal((hidden, 1)) * 0.05).astype(np.float32)
        self.b2 = np.zeros(1, np.float32)

    # ---------- đặc trưng ----------
    @staticmethod
    def features(board):
        idx = []
        for color, off in ((chess.WHITE, 0), (chess.BLACK, 6)):
            occ = board.occupied_co[color]
            for pt, bb in ((1, board.pawns), (2, board.knights), (3, board.bishops),
                           (4, board.rooks), (5, board.queens), (6, board.kings)):
                base = (off + pt - 1) * 64
                for sq in scan(bb & occ):
                    idx.append(base + sq)
        return idx

    # ---------- suy luận ----------
    def eval_cp(self, board):
        idx = self.features(board)
        h = self.b1 + self.W1[idx].sum(axis=0)
        np.maximum(h, 0.0, out=h)
        np.minimum(h, 1.0, out=h)                         # clipped ReLU
        y = math.tanh(float(h @ self.W2[:, 0] + self.b2[0]))
        y = max(-0.995, min(0.995, y))
        return int(self.SCALE * math.atanh(y))            # góc nhìn Trắng

    # ---------- lưu / tải ----------
    def save(self, path=NN_PATH):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        np.savez(path, W1=self.W1, b1=self.b1, W2=self.W2, b2=self.b2)

    @classmethod
    def load(cls, path=NN_PATH):
        if not os.path.exists(path):
            return None
        d = np.load(path)
        nn = cls(hidden=d["W1"].shape[1])
        nn.W1, nn.b1, nn.W2, nn.b2 = d["W1"], d["b1"], d["W2"], d["b2"]
        return nn

    # ---------- huấn luyện ----------
    @staticmethod
    def collect_from_hf(n_positions, progress=None, stop=None):
        """Đọc dạng streaming từ Lichess/chess-position-evaluations (không tải cả dataset)."""
        from datasets import load_dataset
        ds = load_dataset(HF_EVAL_DATASET, split="train", streaming=True)
        X, Y, seen = [], [], set()
        for row in ds:
            if stop is not None and stop.is_set():
                break
            fen = row.get("fen")
            if not fen or fen in seen:
                continue                                  # mỗi FEN có nhiều dòng (nhiều PV) -> lấy dòng đầu
            seen.add(fen)
            cp, mate = row.get("cp"), row.get("mate")
            if cp is None and mate is None:
                continue
            try:
                board = chess.Board(fen)
            except ValueError:
                continue
            if mate is not None:
                target = 1.0 if mate > 0 else -1.0
            else:
                target = math.tanh(max(-2000, min(2000, cp)) / NNEval.SCALE)
            X.append(np.array(NNEval.features(board), np.int16))
            Y.append(target)
            if progress and len(X) % 2000 == 0:
                progress(f"[NN] đã đọc {len(X)}/{n_positions} thế cờ từ Hugging Face")
            if len(X) >= n_positions:
                break
        return X, np.array(Y, np.float32)

    def train(self, X, Y, epochs=4, batch=256, lr=1e-3, progress=None, stop=None):
        n = len(X)
        if n < 100:
            raise ValueError("Quá ít dữ liệu để huấn luyện")
        order = np.random.permutation(n)
        n_val = max(1, n // 20)
        val_idx, tr_idx = order[:n_val], order[n_val:]
        params = [self.W1, self.b1, self.W2, self.b2]
        m = [np.zeros_like(p) for p in params]
        v = [np.zeros_like(p) for p in params]
        b1c, b2c, eps, t = 0.9, 0.999, 1e-8, 0

        def dense(ids):
            xb = np.zeros((len(ids), 768), np.float32)
            for r, i in enumerate(ids):
                xb[r, X[i]] = 1.0
            return xb

        def forward(xb):
            z1 = xb @ self.W1 + self.b1
            h = np.clip(z1, 0.0, 1.0)
            z2 = h @ self.W2 + self.b2
            return z1, h, np.tanh(z2)

        def val_loss():
            xb = dense(val_idx)
            _, _, out = forward(xb)
            return float(np.mean((out[:, 0] - Y[val_idx]) ** 2))

        if progress:
            progress(f"[NN] val MSE ban đầu = {val_loss():.4f}")
        for ep in range(epochs):
            np.random.shuffle(tr_idx)
            for s in range(0, len(tr_idx), batch):
                if stop is not None and stop.is_set():
                    return
                ids = tr_idx[s:s + batch]
                xb, yb = dense(ids), Y[ids][:, None]
                z1, h, out = forward(xb)
                d_out = 2.0 * (out - yb) / len(ids) * (1 - out ** 2)
                gW2 = h.T @ d_out
                gb2 = d_out.sum(0)
                dh = d_out @ self.W2.T
                dz1 = dh * ((z1 > 0) & (z1 < 1))
                gW1 = xb.T @ dz1
                gb1 = dz1.sum(0)
                t += 1
                for i, g in enumerate((gW1, gb1, gW2, gb2)):
                    m[i] = b1c * m[i] + (1 - b1c) * g
                    v[i] = b2c * v[i] + (1 - b2c) * g * g
                    mh = m[i] / (1 - b1c ** t)
                    vh = v[i] / (1 - b2c ** t)
                    params[i] -= (lr * mh / (np.sqrt(vh) + eps)).astype(np.float32)
            if progress:
                progress(f"[NN] epoch {ep + 1}/{epochs}: val MSE = {val_loss():.4f}")


# ============================================================================
# OPENING BOOK - xây từ Hugging Face
# ============================================================================
_FALLBACK_LINES = [   # dùng khi chưa tải được dữ liệu (offline)
    "e2e4 e7e5 g1f3 b8c6 f1b5 a7a6 b5a4 g8f6 e1g1 f8e7",
    "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 c2c3 g8f6 d2d3 d7d6",
    "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 a7a6",
    "e2e4 c7c5 g1f3 b8c6 d2d4 c5d4 f3d4 g8f6 b1c3 e7e5",
    "e2e4 e7e6 d2d4 d7d5 b1c3 g8f6 c1g5 f8e7 e4e5 f6d7",
    "e2e4 c7c6 d2d4 d7d5 b1c3 d5e4 c3e4 c8f5 e4g3 f5g6",
    "d2d4 d7d5 c2c4 e7e6 b1c3 g8f6 c1g5 f8e7 e2e3 e8g8",
    "d2d4 d7d5 c2c4 c7c6 g1f3 g8f6 b1c3 d5c4 a2a4 c8f5",
    "d2d4 g8f6 c2c4 e7e6 b1c3 f8b4 e2e3 e8g8 f1d3 d7d5",
    "d2d4 g8f6 c2c4 g7g6 b1c3 f8g7 e2e4 d7d6 g1f3 e8g8",
    "c2c4 e7e5 b1c3 g8f6 g1f3 b8c6 g2g3 d7d5 c4d5 f6d5",
    "g1f3 d7d5 g2g3 g8f6 f1g2 e7e6 e1g1 f8e7 d2d3 e8g8",
]


class OpeningBook:
    def __init__(self, path=BOOK_PATH):
        self.path = path
        self.data = {}
        self.source = "none"
        self.load()

    @staticmethod
    def key(board):
        return board.epd()          # FEN không có bộ đếm nước -> gộp chuyển vị

    def load(self):
        if os.path.exists(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    self.data = json.load(f)
                self.source = "huggingface"
                return
            except Exception as e:
                log_print("Lỗi đọc opening book:", e)
        self._build_fallback()

    def _build_fallback(self):
        self.data = {}
        for line in _FALLBACK_LINES:
            b = chess.Board()
            for u in line.split():
                mv = chess.Move.from_uci(u)
                d = self.data.setdefault(self.key(b), {})
                d[u] = d.get(u, 0) + 1
                b.push(mv)
        self.source = "built-in"

    def __len__(self):
        return len(self.data)

    def probe(self, board, temperature=1.0, min_count=1):
        entries = self.data.get(self.key(board))
        if not entries:
            return None
        legal = {m.uci(): m for m in board.legal_moves}
        cands = [(u, c) for u, c in entries.items() if u in legal and c >= min_count]
        if not cands:
            return None
        weights = [c ** (1.0 / max(0.05, temperature)) for _, c in cands]
        u = random.choices([u for u, _ in cands], weights=weights)[0]
        return legal[u]

    # ----------------------------------------------------------------------
    _RE_COMMENT = re.compile(r"\{[^}]*\}")
    _RE_MOVENUM = re.compile(r"\d+\.(\.\.)?")
    _RE_RESULT = re.compile(r"(1-0|0-1|1/2-1/2|\*)\s*$")

    @classmethod
    def parse_movetext(cls, text):
        text = cls._RE_COMMENT.sub(" ", text)
        text = cls._RE_RESULT.sub(" ", text)
        text = cls._RE_MOVENUM.sub(" ", text)
        out = []
        for tok in text.split():
            if tok.startswith("$"):
                continue
            tok = tok.rstrip("?!")
            if tok and tok not in ("1-0", "0-1", "1/2-1/2", "*"):
                out.append(tok)
        return out

    def build_from_hf(self, n_games=20000, max_plies=16, min_elo=1900, progress=None, stop=None,
                      year_month="2024-01"):
        """Đọc streaming các ván Lichess từ Hugging Face, đếm tần suất nước đi ở khai cuộc."""
        from datasets import load_dataset
        ds = None
        if year_month:
            y, mo = year_month.split("-")
            try:   # chọn 1 tháng cụ thể (dataset chia thư mục data/year=YYYY/month=MM)
                ds = load_dataset(HF_GAMES_DATASET, split="train", streaming=True,
                                  data_files=f"data/year={y}/month={mo}/*.parquet")
            except Exception as e:
                if progress:
                    progress(f"[Book] không mở được tháng {year_month} ({e}); dùng toàn bộ dataset")
        if ds is None:
            ds = load_dataset(HF_GAMES_DATASET, split="train", streaming=True)

        data, used, scanned = {}, 0, 0
        for row in ds:
            if stop is not None and stop.is_set():
                break
            scanned += 1
            try:
                we, be = int(row.get("WhiteElo") or 0), int(row.get("BlackElo") or 0)
            except (TypeError, ValueError):
                continue
            if min(we, be) < min_elo:
                continue
            tc = str(row.get("TimeControl") or "")
            try:   # bỏ cờ bullet (< 3 phút)
                if tc and tc != "-" and int(tc.split("+")[0]) < 180:
                    continue
            except ValueError:
                pass
            mt = row.get("movetext") or ""
            sans = self.parse_movetext(mt)
            if len(sans) < 8:
                continue
            b = chess.Board()
            for san in sans[:max_plies]:
                try:
                    mv = b.parse_san(san)
                except ValueError:
                    break
                k = self.key(b)
                d = data.setdefault(k, {})
                u = mv.uci()
                d[u] = d.get(u, 0) + 1
                b.push(mv)
            used += 1
            if progress and used % 500 == 0:
                progress(f"[Book] {used}/{n_games} ván (đã quét {scanned})")
            if used >= n_games:
                break

        # bỏ nước hiếm (<2 lần) để book gọn và đáng tin hơn
        pruned = {}
        for k, d in data.items():
            d2 = {u: c for u, c in d.items() if c >= 2}
            if d2:
                pruned[k] = d2
        if pruned:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(pruned, f)
            self.data = pruned
            self.source = "huggingface"
        if progress:
            progress(f"[Book] xong: {used} ván -> {len(pruned)} thế cờ trong book")
        return used


# ============================================================================
# 3 + 4. ENGINE: Negamax/Alpha-beta + các kỹ thuật nâng cấp
# ============================================================================
class SearchTimeout(Exception):
    pass


TT_EXACT, TT_LOWER, TT_UPPER = 0, 1, 2


def elo_params(elo):
    """Ánh xạ Elo (1300-2500) -> giới hạn sức mạnh.  (Ước lượng, chưa được hiệu chuẩn chính xác.)"""
    elo = max(ELO_MIN, min(ELO_MAX, int(elo)))
    t = (elo - ELO_MIN) / (ELO_MAX - ELO_MIN)          # 0..1
    return {
        "elo": elo,
        "movetime": round(0.25 + 2.75 * t, 2),         # giây mỗi nước
        "max_depth": 2 + int(round(6 * t)),            # độ sâu tối đa 2..8
        "blunder_prob": round(0.35 * (1 - t) ** 1.3, 3),  # xác suất chọn nước "kém hơn một chút"
        "margin": int(30 + 220 * (1 - t)),             # nước kém hơn tối đa bao nhiêu cp
        "book_temp": 1.6 - 1.2 * t,                    # Elo thấp: chọn book ngẫu nhiên hơn
        "use_tb": t >= 0.5,
    }


class Engine:
    def __init__(self):
        self.tt = {}
        self.tt_max = 1_500_000
        self.killers = [[None, None] for _ in range(256)]
        self.history = {}
        self.nodes = 0
        self.stop_flag = False
        self.deadline = None
        self.can_stop = False
        self.root_best = None
        self.book = OpeningBook()
        self.nn = NNEval.load()
        self.use_nn = False
        self.nn_weight = 0.5
        self.tb = None
        self._open_tablebase()

    def _open_tablebase(self):
        if os.path.isdir(SYZYGY_DIR):
            try:
                if any(f.endswith(".rtbw") for f in os.listdir(SYZYGY_DIR)):
                    self.tb = chess.syzygy.open_tablebase(SYZYGY_DIR)
            except Exception as e:
                log_print("Không mở được Syzygy:", e)

    def new_game(self):
        self.tt.clear()
        self.history.clear()
        self.killers = [[None, None] for _ in range(256)]

    def stop(self):
        self.stop_flag = True

    # ---------- đánh giá (góc nhìn bên đang đi) ----------
    def evaluate(self, board):
        s = classic_evaluate(board)
        if self.use_nn and self.nn is not None:
            s = int((1 - self.nn_weight) * s + self.nn_weight * self.nn.eval_cp(board))
        return s if board.turn == chess.WHITE else -s

    # ---------- sắp xếp nước đi ----------
    def _order(self, board, tt_move, ply):
        k1, k2 = self.killers[ply] if ply < 256 else (None, None)
        scored = []
        for m in board.legal_moves:
            if m == tt_move:
                s = 10_000_000
            elif board.is_capture(m):
                victim = board.piece_type_at(m.to_square) or chess.PAWN   # en passant
                attacker = board.piece_type_at(m.from_square)
                s = 1_000_000 + PIECE_VALUE[victim] * 10 - PIECE_VALUE[attacker] // 10
            elif m.promotion:
                s = 900_000 + PIECE_VALUE[m.promotion]
            elif m == k1:
                s = 800_000
            elif m == k2:
                s = 790_000
            elif board.gives_check(m):
                s = 700_000
            else:
                s = self.history.get((m.from_square, m.to_square), 0)
            scored.append((s, m))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [m for _, m in scored]

    def _check_time(self):
        if self.stop_flag and self.can_stop:
            raise SearchTimeout
        if self.can_stop and self.deadline is not None and time.perf_counter() > self.deadline:
            raise SearchTimeout

    # ---------- Quiescence search ----------
    def quiesce(self, board, alpha, beta, ply):
        self.nodes += 1
        if (self.nodes & 2047) == 0:
            self._check_time()
        in_check = board.is_check()
        if ply > 60:
            return self.evaluate(board)

        if in_check:          # bị chiếu: phải xét mọi nước thoát chiếu
            best = -INF
            any_move = False
            for m in self._order(board, None, min(ply, 255)):
                any_move = True
                board.push(m)
                sc = -self.quiesce(board, -beta, -alpha, ply + 1)
                board.pop()
                if sc > best:
                    best = sc
                if sc > alpha:
                    alpha = sc
                if alpha >= beta:
                    break
            return best if any_move else -MATE + ply

        stand = self.evaluate(board)
        if stand >= beta:
            return stand
        if stand > alpha:
            alpha = stand

        caps = []
        for m in board.generate_legal_captures():
            victim = board.piece_type_at(m.to_square) or chess.PAWN
            # delta pruning: ăn quân này cũng không đủ kéo lên alpha
            if not m.promotion and stand + PIECE_VALUE[victim] + 200 < alpha:
                continue
            attacker = board.piece_type_at(m.from_square)
            caps.append((PIECE_VALUE[victim] * 10 - PIECE_VALUE[attacker] // 10, m))
        caps.sort(key=lambda x: x[0], reverse=True)
        for _, m in caps:
            board.push(m)
            sc = -self.quiesce(board, -beta, -alpha, ply + 1)
            board.pop()
            if sc >= beta:
                return sc
            if sc > alpha:
                alpha = sc
        return alpha

    # ---------- Negamax + Alpha-beta (PVS) ----------
    def negamax(self, board, depth, alpha, beta, ply, can_null=True):
        self.nodes += 1
        if (self.nodes & 2047) == 0:
            self._check_time()

        if ply > 0:
            if board.halfmove_clock >= 100 or board.is_insufficient_material() or board.is_repetition(2):
                return 0
            # mate distance pruning
            alpha = max(alpha, -MATE + ply)
            beta = min(beta, MATE - ply - 1)
            if alpha >= beta:
                return alpha

        in_check = board.is_check()
        if in_check:
            depth += 1                       # check extension
        if depth <= 0:
            return self.quiesce(board, alpha, beta, ply)

        key = chess.polyglot.zobrist_hash(board)      # Zobrist hashing
        entry = self.tt.get(key)
        tt_move = None
        if entry is not None:
            e_depth, e_flag, e_score, e_move = entry
            tt_move = e_move
            if e_depth >= depth and ply > 0:
                if e_score > MATE_BOUND:
                    e_score -= ply
                elif e_score < -MATE_BOUND:
                    e_score += ply
                if e_flag == TT_EXACT:
                    return e_score
                if e_flag == TT_LOWER and e_score >= beta:
                    return e_score
                if e_flag == TT_UPPER and e_score <= alpha:
                    return e_score

        pv_node = beta - alpha > 1

        # Null-move pruning: "cho đối thủ đi 2 lần" mà vẫn >= beta thì cắt
        if (can_null and not in_check and not pv_node and depth >= 3 and ply > 0 and
                (board.occupied_co[board.turn] & ~(board.pawns | board.kings))):
            if self.evaluate(board) >= beta:
                board.push(chess.Move.null())
                sc = -self.negamax(board, depth - 3, -beta, -beta + 1, ply + 1, False)
                board.pop()
                if sc >= beta:
                    return beta

        moves = self._order(board, tt_move, min(ply, 255))
        if not moves:
            return -MATE + ply if in_check else 0

        orig_alpha = alpha
        best, best_move = -INF, None
        for i, m in enumerate(moves):
            is_cap = board.is_capture(m)
            board.push(m)
            gives_check = board.is_check()
            if i == 0:
                sc = -self.negamax(board, depth - 1, -beta, -alpha, ply + 1)
            else:
                # Late Move Reduction cho các nước yên lặng xếp sau
                red = 0
                if depth >= 3 and i >= 3 and not is_cap and not in_check and not gives_check and not m.promotion:
                    red = 1 if i < 8 else 2
                sc = -self.negamax(board, depth - 1 - red, -alpha - 1, -alpha, ply + 1)
                if sc > alpha and (red or sc < beta):
                    sc = -self.negamax(board, depth - 1, -beta, -alpha, ply + 1)
            board.pop()

            if sc > best:
                best, best_move = sc, m
                if ply == 0:
                    self.root_best = m
                    self.root_score = sc
            if sc > alpha:
                alpha = sc
            if alpha >= beta:
                if not is_cap and ply < 256:
                    k = self.killers[ply]
                    if k[0] != m:
                        k[1], k[0] = k[0], m
                    hk = (m.from_square, m.to_square)
                    self.history[hk] = self.history.get(hk, 0) + depth * depth
                break

        # lưu TT
        flag = TT_EXACT
        if best <= orig_alpha:
            flag = TT_UPPER
        elif best >= beta:
            flag = TT_LOWER
        store = best
        if store > MATE_BOUND:
            store += ply
        elif store < -MATE_BOUND:
            store -= ply
        if len(self.tt) > self.tt_max:
            self.tt.clear()
        self.tt[key] = (depth, flag, store, best_move)
        return best

    def _pv(self, board, max_len=12):
        pv, b = [], board.copy(stack=False)
        for _ in range(max_len):
            e = self.tt.get(chess.polyglot.zobrist_hash(b))
            if not e or e[3] is None or e[3] not in b.legal_moves:
                break
            pv.append(e[3])
            b.push(e[3])
        return pv

    # ---------- Iterative deepening ----------
    def search(self, board, movetime=2.0, max_depth=64, info_cb=None):
        self.nodes = 0
        self.stop_flag = False
        self.can_stop = False
        start = time.perf_counter()
        self.deadline = start + movetime if movetime else None
        legal = list(board.legal_moves)
        if not legal:
            return None, 0, 0
        if len(legal) == 1:
            return legal[0], self.evaluate(board), 0

        best_move, best_score, done_depth = legal[0], 0, 0
        prev = 0
        for depth in range(1, max_depth + 1):
            self.root_best = None
            try:
                # Aspiration window quanh điểm của độ sâu trước
                if depth >= 4 and abs(prev) < MATE_BOUND:
                    a, b = prev - 50, prev + 50
                    sc = self.negamax(board, depth, a, b, 0)
                    if sc <= a or sc >= b:
                        sc = self.negamax(board, depth, -INF, INF, 0)
                else:
                    sc = self.negamax(board, depth, -INF, INF, 0)
            except SearchTimeout:
                break
            finally:
                self.can_stop = True          # luôn hoàn thành ít nhất độ sâu 1
            if self.root_best is not None:
                best_move, best_score, done_depth = self.root_best, sc, depth
            prev = sc
            elapsed = time.perf_counter() - start
            if info_cb:
                info_cb({"depth": depth, "score": sc, "nodes": self.nodes, "time": elapsed,
                         "nps": int(self.nodes / max(elapsed, 1e-6)), "pv": self._pv(board)})
            if abs(sc) > MATE_BOUND:
                break
            if self.deadline and elapsed > movetime * 0.55:
                break                           # không đủ thời gian cho độ sâu tiếp theo
            if self.stop_flag:
                break
        return best_move, best_score, done_depth

    # ---------- Tablebase ----------
    def probe_tablebase(self, board):
        if self.tb is None or popcount(board.occupied) > 7:
            return None
        best, best_key = None, None
        try:
            for m in board.legal_moves:
                board.push(m)
                try:
                    wdl = -self.tb.probe_wdl(board)
                    dtz = self.tb.probe_dtz(board)
                except (KeyError, chess.syzygy.MissingTableError):
                    board.pop()
                    return None
                board.pop()
                # thắng: muốn dtz nhỏ; thua: muốn kéo dài
                k = (wdl, -abs(dtz) if wdl > 0 else abs(dtz))
                if best_key is None or k > best_key:
                    best, best_key = m, k
        except Exception:
            return None
        return best

    # ---------- Hàm chính: chọn nước theo Elo ----------
    def choose_move(self, board, elo=ELO_MAX, use_book=True, info_cb=None, movetime=None, max_depth=None):
        p = elo_params(elo)
        mt = p["movetime"] if movetime is None else movetime
        md = p["max_depth"] if max_depth is None else max_depth

        if use_book and len(self.book):
            mv = self.book.probe(board, temperature=p["book_temp"])
            if mv is not None:
                return mv, {"source": "book"}

        if p["use_tb"]:
            mv = self.probe_tablebase(board)
            if mv is not None:
                return mv, {"source": "tablebase"}

        mv, score, depth = self.search(board, movetime=mt, max_depth=md, info_cb=info_cb)
        info = {"source": "search", "score": score, "depth": depth, "nodes": self.nodes}

        # Giảm sức mạnh cho Elo thấp: đôi khi chọn nước kém hơn một chút (không phải nước bất kỳ)
        if (mv is not None and abs(score) < MATE_BOUND and random.random() < p["blunder_prob"]):
            cands = []
            saved = (self.can_stop, self.deadline)
            self.can_stop, self.deadline = False, None
            for m in board.legal_moves:
                board.push(m)
                s = -self.quiesce(board, -INF, INF, 1)
                board.pop()
                cands.append((s, m))
            self.can_stop, self.deadline = saved
            top = max(s for s, _ in cands)
            pool = [m for s, m in cands if s >= top - p["margin"] and m != mv]
            if pool:
                mv = random.choice(pool)
                info["source"] = "search (giảm Elo)"
        return mv, info


# ============================================================================
# Vẽ bàn cờ bằng OpenCV (dùng làm ảnh dự phòng / không có màn hình)
# ============================================================================
def render_board_cv2(board, last_move=None, flipped=False, sq=64):
    img = np.zeros((sq * 8, sq * 8, 3), np.uint8)
    light, dark = (181, 217, 240), (99, 136, 181)        # BGR
    hl = (106, 210, 205)
    for r in range(8):
        for f in range(8):
            s = chess.square(f, r)
            x = (7 - f if flipped else f) * sq
            y = (r if flipped else 7 - r) * sq
            col = light if (r + f) % 2 else dark
            if last_move and s in (last_move.from_square, last_move.to_square):
                col = hl
            cv2.rectangle(img, (x, y), (x + sq - 1, y + sq - 1), col, -1)
            p = board.piece_at(s)
            if p:
                cx, cy = x + sq // 2, y + sq // 2
                fill = (245, 245, 245) if p.color == chess.WHITE else (30, 30, 30)
                txt = (20, 20, 20) if p.color == chess.WHITE else (240, 240, 240)
                cv2.circle(img, (cx, cy), int(sq * 0.38), fill, -1, cv2.LINE_AA)
                cv2.circle(img, (cx, cy), int(sq * 0.38), (60, 60, 60), 2, cv2.LINE_AA)
                letter = p.symbol().upper()
                (tw, th), _ = cv2.getTextSize(letter, cv2.FONT_HERSHEY_DUPLEX, sq / 64, 2)
                cv2.putText(img, letter, (cx - tw // 2, cy + th // 2), cv2.FONT_HERSHEY_DUPLEX,
                            sq / 64, txt, 2, cv2.LINE_AA)
    if board.is_check():
        k = board.king(board.turn)
        f, r = chess.square_file(k), chess.square_rank(k)
        x = (7 - f if flipped else f) * sq
        y = (r if flipped else 7 - r) * sq
        cv2.rectangle(img, (x + 2, y + 2), (x + sq - 3, y + sq - 3), (40, 40, 220), 3)
    return img


def imwrite_unicode(path, img):
    """cv2.imwrite không xử lý được đường dẫn có dấu tiếng Việt trên Windows -> dùng imencode."""
    ok, buf = cv2.imencode(".png", img)
    if ok:
        buf.tofile(path)
    return ok


# ============================================================================
# 7. CHẾ ĐỘ ĐỌC MÀN HÌNH: tìm bàn cờ trên web, nhận diện quân bằng OpenCV, tự click
# ============================================================================
SCREEN_CFG = os.path.join(DATA_DIR, "screen_config.json")
SCREEN_TPL = os.path.join(DATA_DIR, "screen_templates.npz")
START_PLACEMENT = None   # gán sau khi định nghĩa placement_of


class ScreenGrabber:
    """Chụp màn hình -> ảnh BGR (NumPy). Dùng mss nếu có (nhanh, nhiều màn hình), nếu không thì PIL."""

    def __init__(self):
        self._tl = threading.local()       # mss phải được tạo riêng cho từng luồng

    def _mss(self):
        m = getattr(self._tl, "m", None)
        if m is None:
            import mss
            m = self._tl.m = mss.mss()
        return m

    def grab(self, region=None):
        """region = (x, y, w, h) theo toạ độ màn hình; None = cả màn hình.
        Trả về (ảnh BGR, (x0, y0)) với (x0, y0) là toạ độ màn hình của góc trên-trái ảnh."""
        try:
            m = self._mss()
            if region is None:
                mon = m.monitors[0]
                box = {"left": mon["left"], "top": mon["top"], "width": mon["width"], "height": mon["height"]}
            else:
                x, y, w, h = (int(round(v)) for v in region)
                box = {"left": x, "top": y, "width": w, "height": h}
            img = np.asarray(m.grab(box))[:, :, :3]
            return np.ascontiguousarray(img), (box["left"], box["top"])
        except Exception:
            from PIL import ImageGrab
            if region is None:
                pil = ImageGrab.grab()
                origin = (0, 0)
            else:
                x, y, w, h = (int(round(v)) for v in region)
                pil = ImageGrab.grab(bbox=(x, y, x + w, y + h))
                origin = (x, y)
            return cv2.cvtColor(np.asarray(pil.convert("RGB")), cv2.COLOR_RGB2BGR), origin


def _cell(img, r, c):
    h, w = img.shape[:2]
    return img[int(r * h / 8):int((r + 1) * h / 8), int(c * w / 8):int((c + 1) * w / 8)]


def _corner_color(cell):
    """Màu nền của ô lấy ở góc trên-phải (tránh toạ độ a-h/1-8 và thân quân cờ)."""
    h, w = cell.shape[:2]
    patch = cell[int(h * 0.03):max(int(h * 0.12), int(h * 0.03) + 1), int(w * 0.86):max(int(w * 0.97), int(w * 0.86) + 1)]
    return np.median(patch.reshape(-1, 3), axis=0)


def checker_score(board_img):
    """Mức độ ảnh trông giống bàn cờ (0..1): các ô xen kẽ đúng 2 màu."""
    cols = np.array([[_corner_color(_cell(board_img, r, c)) for c in range(8)] for r in range(8)], np.float32)
    even = cols[(np.add.outer(np.arange(8), np.arange(8)) % 2) == 0]
    odd = cols[(np.add.outer(np.arange(8), np.arange(8)) % 2) == 1]
    ce, co = np.median(even, 0), np.median(odd, 0)
    if np.linalg.norm(ce - co) < 30:
        return 0.0
    ok_e = np.linalg.norm(even - ce, axis=1) < np.linalg.norm(even - co, axis=1)
    ok_o = np.linalg.norm(odd - co, axis=1) < np.linalg.norm(odd - ce, axis=1)
    return float((ok_e.sum() + ok_o.sum()) / 64.0)


def detect_board(img, min_size=120):
    """Tìm bàn cờ trong ảnh màn hình mà không cần biết trước màu: thử các cặp màu phổ biến nhất,
    lấy vùng gần vuông lớn nhất có hoạ tiết ô cờ. Trả về (x, y, w, h) trong toạ độ ảnh hoặc None."""
    scale = 0.5 if max(img.shape[:2]) > 900 else 1.0
    small = cv2.resize(img, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA) if scale != 1 else img
    q = (small // 8).astype(np.int32)
    codes = (q[..., 0] << 10) | (q[..., 1] << 5) | q[..., 2]
    vals, counts = np.unique(codes, return_counts=True)
    top = vals[np.argsort(-counts)[:10]]
    colors = [np.array([(v >> 10) & 31, (v >> 5) & 31, v & 31], np.float32) * 8 + 4 for v in top]
    sf = small.astype(np.float32)
    k = max(7, int(min_size * scale / 8) | 1)
    best, best_val = None, 0
    for i in range(len(colors)):
        for j in range(i + 1, len(colors)):
            c1, c2 = colors[i], colors[j]
            if np.linalg.norm(c1 - c2) < 40:
                continue
            m = ((np.linalg.norm(sf - c1, axis=2) < 22) | (np.linalg.norm(sf - c2, axis=2) < 22)).astype(np.uint8)
            m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((k, k), np.uint8))
            cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for cn in cnts:
                x, y, w, h = cv2.boundingRect(cn)
                if min(w, h) < min_size * scale or abs(w - h) > 0.08 * max(w, h):
                    continue
                if cv2.contourArea(cv2.convexHull(cn)) < 0.9 * w * h:
                    continue
                X0, Y0, X1, Y1 = int(x / scale), int(y / scale), int((x + w) / scale), int((y + h) / scale)
                sc = checker_score(img[Y0:Y1, X0:X1])      # chấm điểm ở độ phân giải gốc
                val = sc * w * h
                if sc >= 0.85 and val > best_val:
                    best, best_val = (x / scale, y / scale, w / scale, h / scale, c1, c2), val
    if best is None:
        return None
    return _refine_board(img, *best)


def _refine_board(img, x, y, w, h, c1, c2):
    """Tinh chỉnh biên bàn cờ ở độ phân giải gốc với 2 màu ô chính xác."""
    H, W = img.shape[:2]
    pad = int(max(w, h) / 16)
    X0, Y0 = max(0, int(x) - pad), max(0, int(y) - pad)
    X1, Y1 = min(W, int(x + w) + pad), min(H, int(y + h) + pad)
    crop = img[Y0:Y1, X0:X1]
    cf = crop.astype(np.float32)
    # màu ô chính xác = trung vị các điểm ảnh gần màu lượng tử hoá
    cols = []
    for c in (c1, c2):
        near = np.linalg.norm(cf - c, axis=2) < 22
        cols.append(np.median(cf[near], axis=0) if near.any() else c)
    m = ((np.linalg.norm(cf - cols[0], axis=2) < 18) | (np.linalg.norm(cf - cols[1], axis=2) < 18)).astype(np.uint8)
    k = max(7, int(max(w, h) / 24) | 1)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((k, k), np.uint8))
    cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return (x, y, w, h)
    cn = max(cnts, key=cv2.contourArea)
    rx, ry, rw, rh = cv2.boundingRect(cn)
    if abs(rw - w) > w * 0.1 or abs(rh - h) > h * 0.1:
        return (x, y, w, h)
    return (float(X0 + rx), float(Y0 + ry), float(rw), float(rh))


# ---------------------------------------------------------------- nhận diện quân
FEAT = 32


def _bg_color(cell):
    """Màu nền ô = màu xuất hiện nhiều nhất ở viền ô (đúng cả khi ô đang được tô sáng nước vừa đi)."""
    b0, b1 = 1, 4
    border = np.concatenate([cell[b0:b1].reshape(-1, 3), cell[-b1:-b0].reshape(-1, 3),
                             cell[:, b0:b1].reshape(-1, 3), cell[:, -b1:-b0].reshape(-1, 3)]).astype(np.float32)
    qz = (border // 12).astype(np.int32)
    codes = qz[:, 0] * 441 + qz[:, 1] * 21 + qz[:, 2]
    vals, cnt = np.unique(codes, return_counts=True)
    return border[codes == vals[cnt.argmax()]].mean(0)


def _solid_mask(fg):
    """Lấp kín phần bên trong viền quân (quân Trắng trên ô sáng chỉ khác nền ở đường viền),
    rồi giữ thành phần liên thông lớn nhất (bỏ chữ toạ độ, chấm gợi ý...)."""
    h, w = fg.shape
    inv = np.ones((h + 2, w + 2), np.uint8)
    inv[1:-1, 1:-1] = 1 - fg
    mask = np.zeros((h + 4, w + 4), np.uint8)
    cv2.floodFill(inv, mask, (0, 0), 2)
    solid = (inv[1:-1, 1:-1] != 2).astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(solid, connectivity=8)
    if n <= 1:
        return np.zeros_like(solid)
    i = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return (lab == i).astype(np.uint8)


def square_feature(cell):
    """Đặc trưng của 1 ô: hình dạng quân (mặt nạ) + độ sáng của quân, chuẩn hoá về 32x32.
    Không phụ thuộc màu ô nên quân học trên ô sáng vẫn nhận ra khi đứng trên ô tối."""
    c = cell.astype(np.float32)
    bg = _bg_color(c)
    d = np.sqrt(((c - bg) ** 2).sum(2))
    h, w = d.shape
    m = max(1, int(round(0.04 * min(h, w))))
    d, g = d[m:h - m, m:w - m], c[m:h - m, m:w - m].mean(2)
    fg = (d > 34).astype(np.uint8)
    solid = _solid_mask(fg)
    ratio = float(solid.mean())
    ms = cv2.resize(solid.astype(np.float32), (FEAT, FEAT), interpolation=cv2.INTER_AREA)
    gs = cv2.resize(g * solid / 255.0, (FEAT, FEAT), interpolation=cv2.INTER_AREA)
    return np.concatenate([ms.ravel(), 1.5 * gs.ravel()]).astype(np.float32), ratio, \
        (float((g * solid).sum() / max(1, solid.sum())) if solid.any() else 0.0)


def screen_to_square(r, c, flipped):
    return chess.square(7 - c, r) if flipped else chess.square(c, 7 - r)


def placement_of(board):
    return {sq: p.symbol() for sq, p in board.piece_map().items()}


START_PLACEMENT = placement_of(chess.Board())


class PieceClassifier:
    """Phân loại 13 lớp (6 quân x 2 màu + ô trống) bằng láng giềng gần nhất.
    Mẫu được học từ CHÍNH bàn cờ trên màn hình ở thế ban đầu, nên dùng được với mọi bộ quân/màu ô."""
    EMPTY_RATIO = 0.035

    def __init__(self):
        self.X = None
        self.y = None

    @property
    def ready(self):
        return self.X is not None and len(self.X) > 0

    @staticmethod
    def check_start_and_orientation(board_img):
        """Kiểm tra ảnh có đúng là thế ban đầu không; trả về flipped (True = Đen ở dưới) hoặc ném lỗi."""
        ratio = np.zeros((8, 8))
        bright = np.zeros((8, 8))
        for r in range(8):
            for c in range(8):
                _, ratio[r, c], bright[r, c] = square_feature(_cell(board_img, r, c))
        occ = ratio > PieceClassifier.EMPTY_RATIO
        if occ[[0, 1, 6, 7]].sum() < 30 or occ[2:6].sum() > 2:
            raise ValueError("Bàn cờ trên màn hình không ở thế ban đầu (cần 32 quân ở 4 hàng ngoài cùng).")
        top, bottom = bright[[0, 1]].mean(), bright[[6, 7]].mean()
        return bool(top > bottom)          # quân sáng (Trắng) ở trên -> bàn cờ bị lật

    def fit_from_start(self, board_img):
        flipped = self.check_start_and_orientation(board_img)
        start = chess.Board()
        X, y = [], []
        h, w = board_img.shape[:2]
        cw, ch = w / 8, h / 8
        jit = max(1, int(round(min(cw, ch) / 30)))
        for r in range(8):
            for c in range(8):
                p = start.piece_at(screen_to_square(r, c, flipped))
                lab = p.symbol() if p else "."
                for dx, dy in ((0, 0), (jit, 0), (-jit, 0), (0, jit), (0, -jit)):
                    x0, y0 = int(c * cw) + dx, int(r * ch) + dy
                    x0, y0 = max(0, x0), max(0, y0)
                    cell = board_img[y0:min(h, y0 + int(ch)), x0:min(w, x0 + int(cw))]
                    f, _, _ = square_feature(cell)
                    X.append(f)
                    y.append(lab)
        self.X, self.y = np.stack(X), np.array(y)
        return flipped

    def predict_cells(self, board_img):
        """Trả về list 64 nhãn theo thứ tự màn hình (hàng trên cùng trước), '.' = trống."""
        feats, out = [], []
        for r in range(8):
            for c in range(8):
                f, ratio, _ = square_feature(_cell(board_img, r, c))
                feats.append(f)
                out.append("." if ratio < self.EMPTY_RATIO else None)
        F = np.stack(feats)
        if getattr(self, "_x2", None) is None or len(self._x2) != len(self.X):
            self._x2 = (self.X ** 2).sum(1)
        d = (F ** 2).sum(1)[:, None] + self._x2[None, :] - 2.0 * (F @ self.X.T)   # khoảng cách L2 bằng phép nhân ma trận
        nn = self.y[d.argmin(1)]
        return [o if o is not None else nn[i] for i, o in enumerate(out)]

    def predict_placement(self, board_img, flipped):
        labels = self.predict_cells(board_img)
        pos = {}
        for i, lab in enumerate(labels):
            if lab != ".":
                pos[screen_to_square(i // 8, i % 8, flipped)] = lab
        return pos, labels

    def save(self, path=SCREEN_TPL):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        np.savez_compressed(path, X=self.X, y=self.y)

    @classmethod
    def load(cls, path=SCREEN_TPL):
        if not os.path.exists(path):
            return None
        d = np.load(path)
        c = cls()
        c.X, c.y = d["X"], d["y"]
        return c


class MouseController:
    """Điều khiển chuột bằng pyautogui. Đưa chuột vào góc màn hình để dừng khẩn cấp (FailSafe)."""

    def __init__(self):
        import pyautogui
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.02
        self.pg = pyautogui

    def click(self, x, y):
        self.pg.moveTo(int(x), int(y), duration=0.06)
        self.pg.click()

    def drag(self, x1, y1, x2, y2):
        self.pg.moveTo(int(x1), int(y1), duration=0.06)
        self.pg.mouseDown()
        self.pg.moveTo(int(x2), int(y2), duration=0.18)
        self.pg.mouseUp()

    def move(self, x, y):
        self.pg.moveTo(int(x), int(y), duration=0.05)


def match_move(board, pos):
    """Tìm nước đi hợp lệ biến thế `board` thành thế `pos` đọc từ màn hình."""
    for m in board.legal_moves:
        board.push(m)
        same = placement_of(board) == pos
        board.pop()
        if same:
            return m
    return None


def board_from_placement(pos, turn):
    """Dựng lại thế cờ khi vào giữa ván (không biết lịch sử): suy ra quyền nhập thành từ vị trí Vua/Xe."""
    b = chess.Board(None)
    b.set_piece_map({sq: chess.Piece.from_symbol(s) for sq, s in pos.items()})
    b.turn = turn
    cf = ""
    if pos.get(chess.E1) == "K":
        cf += ("K" if pos.get(chess.H1) == "R" else "") + ("Q" if pos.get(chess.A1) == "R" else "")
    if pos.get(chess.E8) == "k":
        cf += ("k" if pos.get(chess.H8) == "r" else "") + ("q" if pos.get(chess.A8) == "r" else "")
    b.set_castling_fen(cf or "-")
    return b


class ScreenBot:
    """Vòng lặp chơi trên màn hình: đọc thế cờ -> phát hiện nước của đối thủ -> engine tính -> click.
    Bot luôn cầm bên quân đang ở PHÍA DƯỚI bàn cờ trên màn hình (như khi bạn chơi trên web)."""

    def __init__(self, engine, engine_lock, grabber, mouse, clf, region, emit, settings):
        self.engine, self.lock, self.grabber, self.mouse = engine, engine_lock, grabber, mouse
        self.clf, self.region, self.emit, self.settings = clf, region, emit, settings
        self.flipped = False
        self.bot_color = chess.WHITE
        self.board = None
        self.paused = False
        self.stop_ev = threading.Event()
        self.thread = None
        self.gen = 0
        self.resync = False

    # ------------------------------------------------------------ đọc màn hình
    def read(self):
        img, _ = self.grabber.grab(self.region)
        pos, _ = self.clf.predict_placement(img, self.flipped)
        return pos, img

    def stable_read(self, tries=8, gap=0.12):
        """Đọc tới khi 2 lần liên tiếp giống nhau (bỏ qua khung hình đang chạy hiệu ứng di chuyển)."""
        prev = None
        for _ in range(tries):
            pos, img = self.read()
            if prev is not None and pos == prev:
                return pos, img
            prev = pos
            self._sleep(gap)
        return pos, img

    def _sleep(self, t):
        self.stop_ev.wait(t)

    def center(self, sq):
        f, r = chess.square_file(sq), chess.square_rank(sq)
        c, row = (7 - f, r) if self.flipped else (f, 7 - r)
        x, y, w, h = self.region
        return x + (c + 0.5) * w / 8, y + (row + 0.5) * h / 8

    # ------------------------------------------------------------ khởi tạo ván
    def setup(self):
        img, _ = self.grabber.grab(self.region)
        labels = self.clf.predict_cells(img)
        rows_white = [i // 8 for i, l in enumerate(labels) if l not in (".",) and l.isupper()]
        rows_black = [i // 8 for i, l in enumerate(labels) if l not in (".",) and l.islower()]
        if not rows_white or not rows_black:
            raise ValueError("Không đọc được quân trên bàn cờ — hãy bấm 'Học quân' ở thế ban đầu.")
        self.flipped = np.mean(rows_white) < np.mean(rows_black)
        self.bot_color = chess.BLACK if self.flipped else chess.WHITE
        pos, img = self.stable_read()
        start = chess.Board()
        if pos == START_PLACEMENT:
            self.board = start
            note = "thế ban đầu"
        else:
            m = match_move(start, pos)
            if m is not None:
                first_san = start.san(m)
                start.push(m)
                self.board = start
                note = f"sau nước {first_san} của Trắng"
            else:
                self.board = board_from_placement(pos, self.bot_color)
                if not self.board.is_valid():
                    raise ValueError("Thế cờ đọc được không hợp lệ — kiểm tra lại vùng bàn cờ / học quân lại.")
                note = "giữa ván (giả định đang tới lượt bot)"
        side = "Trắng" if self.bot_color == chess.WHITE else "Đen"
        self.emit("log", f"[Màn hình] Bot cầm {side} (bên dưới), {note}.")
        if len(self.board.move_stack) == 1:
            self.emit("sboard", chess.Board(), self.flipped, None)
            self.emit("smove", self.board.copy(), first_san, "Đối thủ", img, None)
        else:
            self.emit("sboard", self.board.copy(), self.flipped, img)

    # ------------------------------------------------------------ đi quân
    def play(self, mv, use_drag):
        x1, y1 = self.center(mv.from_square)
        x2, y2 = self.center(mv.to_square)
        if use_drag:
            self.mouse.drag(x1, y1, x2, y2)
        else:
            self.mouse.click(x1, y1)
            self._sleep(0.08)
            self.mouse.click(x2, y2)
        if mv.promotion:
            # Hầu hết trang web hiện bảng chọn quân ngay tại ô phong cấp, Hậu nằm ở ô đầu tiên
            self._sleep(0.4)
            self.mouse.click(x2, y2)
        x, y, w, h = self.region
        self.mouse.move(x + w + 25, y + h / 2)     # đưa chuột ra khỏi bàn cờ

    def wait_confirm(self, expected, timeout=3.0):
        """Đợi màn hình hiện nước bot vừa đi. Nếu đối thủ trả lời ngay (máy của trang web) cũng chấp nhận."""
        t_end = time.time() + timeout
        target = placement_of(expected)
        last_reply = None
        while time.time() < t_end and not self.stop_ev.is_set():
            pos, img = self.read()
            if pos == target:
                return True, None, img
            reply = match_move(expected, pos)
            if reply is not None:
                if reply == last_reply:
                    return True, reply, img
                last_reply = reply
            self._sleep(0.12)
        return False, None, None

    # ------------------------------------------------------------ vòng lặp chính
    def run(self):
        try:
            self.setup()
        except Exception as e:
            self.emit("log", f"[Màn hình] {e}")
            self.emit("sstopped")
            return
        mismatch_since = None
        try:
            while not self.stop_ev.is_set():
                if self.paused:
                    self._sleep(0.1)
                    continue
                if self.resync:
                    self.resync = False
                    self.setup()
                    continue
                if self.board.is_game_over(claim_draw=True):
                    self.emit("sgameover", self.board.copy())
                    break

                if self.board.turn == self.bot_color:
                    gen = self.gen
                    s = dict(self.settings)
                    with self.lock:
                        self.engine.use_nn = s.get("use_nn", False) and self.engine.nn is not None
                        mv, info = self.engine.choose_move(
                            self.board.copy(), s.get("elo", 1800), s.get("use_book", True),
                            lambda d: self.emit("sinfo", d, self.board.turn))
                    if self.paused or self.stop_ev.is_set() or gen != self.gen or mv is None:
                        continue
                    expected = self.board.copy()
                    san = expected.san(mv)
                    expected.push(mv)
                    ok, reply, img = False, None, None
                    for attempt in range(2):
                        self.play(mv, s.get("drag", False) ^ (attempt == 1))   # lần 2 đổi cách click/kéo
                        ok, reply, img = self.wait_confirm(expected)
                        if ok:
                            break
                        pos, _ = self.stable_read()
                        if pos != placement_of(self.board):
                            break          # màn hình đã thay đổi theo cách khác -> không thử lại
                    if not ok:
                        self.emit("log", f"[Màn hình] Không thấy nước {san} xuất hiện trên bàn cờ. "
                                         "Đã tạm dừng — kiểm tra rồi bấm 'Đồng bộ lại' + F1.")
                        self.paused = True
                        self.emit("spaused")
                        continue
                    self.board.push(mv)
                    self.emit("smove", self.board.copy(), san, "Bot", img, info)
                    if reply is not None:
                        rsan = self.board.san(reply)
                        self.board.push(reply)
                        self.emit("smove", self.board.copy(), rsan, "Đối thủ", img, None)
                    mismatch_since = None
                else:
                    pos, img = self.read()
                    if pos == placement_of(self.board):
                        mismatch_since = None
                        self._sleep(0.15)
                        continue
                    pos, img = self.stable_read()
                    if pos == placement_of(self.board):
                        continue
                    mv = match_move(self.board, pos)
                    if mv is not None:
                        san = self.board.san(mv)
                        self.board.push(mv)
                        self.emit("smove", self.board.copy(), san, "Đối thủ", img, None)
                        mismatch_since = None
                    else:
                        if mismatch_since is None:
                            mismatch_since = time.time()
                        elif time.time() - mismatch_since > 4:
                            self.emit("log", "[Màn hình] Thế cờ trên màn hình không khớp với nước đi hợp lệ nào "
                                             "(bàn cờ bị che, đổi giao diện, hoặc đi 2 nước?). Bấm 'Đồng bộ lại' nếu cần.")
                            mismatch_since = time.time() + 26          # nhắc lại sau ~30s
                        self._sleep(0.3)
        except Exception as e:      # gồm pyautogui.FailSafeException khi đưa chuột vào góc màn hình
            self.emit("log", f"[Màn hình] Dừng: {type(e).__name__}: {e}")
        self.emit("sstopped")

    def start(self):
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_ev.set()
        self.gen += 1
        self.engine.stop()


# ============================================================================
# 5. GIAO THỨC UCI
# ============================================================================
def uci_loop():
    engine = Engine()
    board = chess.Board()
    opts = {"UCI_LimitStrength": False, "UCI_Elo": 2000, "OwnBook": True, "UseNN": False}
    worker = None

    def out(s):
        print(s, flush=True)

    def info_cb(d):
        sc = d["score"]
        if abs(sc) > MATE_BOUND:
            mate_in = (MATE - abs(sc) + 1) // 2
            s_txt = f"mate {mate_in if sc > 0 else -mate_in}"
        else:
            s_txt = f"cp {sc}"
        out(f"info depth {d['depth']} score {s_txt} nodes {d['nodes']} nps {d['nps']} "
            f"time {int(d['time'] * 1000)} pv {' '.join(m.uci() for m in d['pv'])}")

    def go(b, movetime, depth):
        engine.use_nn = opts["UseNN"]
        if opts["UCI_LimitStrength"]:
            p = elo_params(opts["UCI_Elo"])
            mt = min(movetime, p["movetime"]) if movetime else p["movetime"]
            mv, _ = engine.choose_move(b, opts["UCI_Elo"], opts["OwnBook"], info_cb, movetime=mt,
                                       max_depth=depth or p["max_depth"])
        else:
            mv = None
            if opts["OwnBook"]:
                mv = engine.book.probe(b, temperature=0.4)
            if mv is None:
                mv = engine.probe_tablebase(b)
            if mv is None:
                mv, _, _ = engine.search(b, movetime=movetime, max_depth=depth or 64, info_cb=info_cb)
        out(f"bestmove {mv.uci() if mv else '0000'}")

    for line in sys.stdin:
        tok = line.strip().split()
        if not tok:
            continue
        cmd = tok[0]
        if cmd == "uci":
            out("id name ChessAI-UET")
            out("id author student")
            out("option name UCI_LimitStrength type check default false")
            out(f"option name UCI_Elo type spin default 2000 min {ELO_MIN} max {ELO_MAX}")
            out("option name OwnBook type check default true")
            out("option name UseNN type check default false")
            out("uciok")
        elif cmd == "isready":
            out("readyok")
        elif cmd == "setoption":
            try:
                ni = tok.index("name")
                vi = tok.index("value") if "value" in tok else len(tok)
                name = " ".join(tok[ni + 1:vi])
                val = " ".join(tok[vi + 1:])
                if name in ("UCI_LimitStrength", "OwnBook", "UseNN"):
                    opts[name] = val.lower() == "true"
                elif name == "UCI_Elo":
                    opts[name] = int(val)
            except ValueError:
                pass
        elif cmd == "ucinewgame":
            engine.new_game()
        elif cmd == "position":
            if len(tok) > 1 and tok[1] == "startpos":
                board = chess.Board()
                rest = tok[2:]
            elif len(tok) > 1 and tok[1] == "fen":
                mi = tok.index("moves") if "moves" in tok else len(tok)
                board = chess.Board(" ".join(tok[2:mi]))
                rest = tok[mi:]
            else:
                continue
            if rest and rest[0] == "moves":
                for u in rest[1:]:
                    board.push_uci(u)
        elif cmd == "go":
            args = {}
            i = 1
            while i < len(tok):
                if tok[i] in ("wtime", "btime", "winc", "binc", "movestogo", "movetime", "depth"):
                    args[tok[i]] = int(tok[i + 1])
                    i += 2
                else:
                    args[tok[i]] = True
                    i += 1
            if "movetime" in args:
                mt = args["movetime"] / 1000
            elif "infinite" in args:
                mt = None
            elif "wtime" in args or "btime" in args:
                rem = args.get("wtime" if board.turn == chess.WHITE else "btime", 60000) / 1000
                inc = args.get("winc" if board.turn == chess.WHITE else "binc", 0) / 1000
                mtg = args.get("movestogo", 30)
                mt = max(0.05, min(rem / mtg + inc * 0.8, rem / 5))
            elif "depth" in args:
                mt = None
            else:
                mt = 2.0
            if worker and worker.is_alive():
                engine.stop()
                worker.join()
            worker = threading.Thread(target=go, args=(board.copy(), mt, args.get("depth")), daemon=True)
            worker.start()
        elif cmd == "stop":
            engine.stop()
            if worker:
                worker.join()
        elif cmd == "quit":
            engine.stop()
            break


# ============================================================================
# GIAO DIỆN (Tkinter)
# ============================================================================
GLYPH_FILLED = {chess.KING: "♚", chess.QUEEN: "♛", chess.ROOK: "♜",
                chess.BISHOP: "♝", chess.KNIGHT: "♞", chess.PAWN: "♟"}
GLYPH_OUTLINE = {chess.KING: "♔", chess.QUEEN: "♕", chess.ROOK: "♖",
                 chess.BISHOP: "♗", chess.KNIGHT: "♘", chess.PAWN: "♙"}


def run_gui():
    import tkinter as tk
    from tkinter import ttk, messagebox

    if sys.platform == "win32":     # để ImageGrab chụp đúng vị trí khi Windows phóng to giao diện
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass

    SQ = 72
    LIGHT, DARK = "#f0d9b5", "#b58863"
    LAST, SEL, CHECK = "#cdd26a", "#f6f669", "#e05c5c"
    BG, PANEL, FG, ACCENT = "#1f2328", "#2a2f36", "#e6e6e6", "#4fa3ff"
    PIECE_FONT_CANDIDATES = ["Segoe UI Symbol", "Segoe UI Emoji", "Apple Symbols", "Arial Unicode MS",
                             "DejaVu Sans", "Noto Sans Symbols2", "FreeSerif", "Symbola"]

    class App:
        def __init__(self, root):
            self.root = root
            self.engine = Engine()
            self.board = chess.Board()
            self.started = False
            self.paused = False
            self.thinking = False
            self.gen = 0                    # tăng mỗi lần ván/huỷ suy nghĩ -> bỏ kết quả cũ
            self.selected = None
            self.flipped = False
            self.q = queue.Queue()
            self.bg_stop = threading.Event()
            self.bg_busy = False
            self.shot_dir = None
            self.shot_count = 0
            self.engine_lock = threading.Lock()   # mỗi lúc chỉ 1 luồng dùng engine
            # chế độ đọc màn hình
            self.grabber = ScreenGrabber()
            self.sregion = None
            self.sclf = PieceClassifier.load()
            self.sbot = None
            self.settings = {}
            try:
                with open(SCREEN_CFG, "r", encoding="utf-8") as f:
                    self.sregion = tuple(json.load(f)["region"])
            except Exception:
                pass

            import tkinter.font as tkfont
            fams = set(tkfont.families(root))
            fam = next((f for f in PIECE_FONT_CANDIDATES if f in fams), None)
            # không có font chứa ký hiệu quân cờ -> vẽ quân bằng hình tròn + chữ cái
            self.piece_font = (fam, int(SQ * 0.6)) if fam else None
            root.title("ChessAI — F1: Bắt đầu  |  F2: Tạm dừng  |  F3: Thoát")
            root.configure(bg=BG)
            root.protocol("WM_DELETE_WINDOW", self.quit)
            self._build_ui()
            self._setup_hotkeys()
            self.redraw()
            self.log(f"Opening book: {len(self.engine.book)} thế cờ (nguồn: {self.engine.book.source})")
            self.log("Mạng neural: " + ("đã tải" if self.engine.nn else "chưa có (bấm 'Huấn luyện NN')"))
            if self.engine.tb:
                self.log("Đã mở Syzygy tablebase.")
            self.set_status("Bấm F1 để bắt đầu ván cờ")
            self.update_screen_label()
            self.root.after(40, self.poll)
            if self.engine.book.source != "huggingface":
                self.root.after(800, lambda: self.build_book(auto=True))

        # ------------------------------------------------------------------ UI
        def _build_ui(self):
            st = ttk.Style()
            try:
                st.theme_use("clam")
            except tk.TclError:
                pass
            st.configure(".", background=PANEL, foreground=FG, fieldbackground=PANEL)
            st.configure("TLabel", background=PANEL, foreground=FG)
            st.configure("TFrame", background=PANEL)
            st.configure("TLabelframe", background=PANEL, foreground=FG)
            st.configure("TLabelframe.Label", background=PANEL, foreground=ACCENT, font=("Segoe UI", 10, "bold"))
            st.configure("TRadiobutton", background=PANEL, foreground=FG)
            st.configure("TCheckbutton", background=PANEL, foreground=FG)
            st.configure("TButton", padding=5)
            st.configure("Big.TButton", font=("Segoe UI", 10, "bold"), padding=7)
            st.configure("Status.TLabel", font=("Segoe UI", 12, "bold"), foreground="#ffd866", background=BG)

            left = tk.Frame(self.root, bg=BG)
            left.pack(side="left", padx=12, pady=12)
            self.status = ttk.Label(left, text="", style="Status.TLabel")
            self.status.pack(anchor="w", pady=(0, 6))
            self.canvas = tk.Canvas(left, width=SQ * 8, height=SQ * 8, highlightthickness=0, bg=BG)
            self.canvas.pack()
            self.canvas.bind("<Button-1>", self.on_click)
            self.eval_bar = tk.Canvas(left, width=SQ * 8, height=14, highlightthickness=0, bg="#333")
            self.eval_bar.pack(pady=(6, 0))

            right = ttk.Frame(self.root, padding=10)
            right.pack(side="left", fill="both", expand=True, padx=(0, 12), pady=12)

            row = ttk.Frame(right)
            row.pack(fill="x")
            ttk.Button(row, text="▶ Bắt đầu (F1)", style="Big.TButton", command=self.hk_start).pack(side="left", expand=True, fill="x", padx=2)
            ttk.Button(row, text="⏸ Tạm dừng (F2)", style="Big.TButton", command=self.hk_pause).pack(side="left", expand=True, fill="x", padx=2)
            ttk.Button(row, text="⏹ Thoát (F3)", style="Big.TButton", command=self.quit).pack(side="left", expand=True, fill="x", padx=2)

            lf = ttk.LabelFrame(right, text="Sức mạnh (Elo)", padding=8)
            lf.pack(fill="x", pady=8)
            self.elo = tk.IntVar(value=1800)
            self.elo_lbl = ttk.Label(lf, text="")
            self.elo_lbl.pack(anchor="w")
            tk.Scale(lf, from_=ELO_MIN, to=ELO_MAX, resolution=50, orient="horizontal", variable=self.elo,
                     command=lambda _=None: self.update_elo_label(), bg=PANEL, fg=FG, troughcolor="#444",
                     highlightthickness=0, length=330, showvalue=True).pack(fill="x")
            self.update_elo_label()

            lf = ttk.LabelFrame(right, text="Ván cờ", padding=8)
            lf.pack(fill="x")
            self.mode = tk.StringVar(value="hvb")
            self.human_color = tk.StringVar(value="white")
            r1 = ttk.Frame(lf)
            r1.pack(fill="x")
            ttk.Radiobutton(r1, text="Người vs Máy", variable=self.mode, value="hvb", command=self.maybe_bot).pack(side="left")
            ttk.Radiobutton(r1, text="Máy vs Máy", variable=self.mode, value="bvb", command=self.maybe_bot).pack(side="left", padx=10)
            ttk.Radiobutton(r1, text="Bot trên màn hình (web)", variable=self.mode, value="screen").pack(side="left")
            r2 = ttk.Frame(lf)
            r2.pack(fill="x", pady=4)
            ttk.Label(r2, text="Bạn cầm:").pack(side="left")
            ttk.Radiobutton(r2, text="Trắng", variable=self.human_color, value="white", command=self.on_color).pack(side="left", padx=4)
            ttk.Radiobutton(r2, text="Đen", variable=self.human_color, value="black", command=self.on_color).pack(side="left")
            self.use_book = tk.BooleanVar(value=True)
            self.use_nn = tk.BooleanVar(value=False)
            self.do_shots = tk.BooleanVar(value=True)
            self.shot_src = tk.StringVar(value="screen")
            ttk.Checkbutton(lf, text="Dùng opening book", variable=self.use_book).pack(anchor="w")
            ttk.Checkbutton(lf, text="Dùng mạng neural trong hàm đánh giá", variable=self.use_nn).pack(anchor="w")
            ttk.Checkbutton(lf, text="Chụp ảnh bàn cờ sau mỗi nước đi", variable=self.do_shots).pack(anchor="w")
            r3 = ttk.Frame(lf)
            r3.pack(fill="x")
            ttk.Label(r3, text="   Nguồn ảnh:").pack(side="left")
            ttk.Radiobutton(r3, text="Chụp màn hình", variable=self.shot_src, value="screen").pack(side="left")
            ttk.Radiobutton(r3, text="Vẽ OpenCV", variable=self.shot_src, value="render").pack(side="left", padx=6)
            r4 = ttk.Frame(lf)
            r4.pack(fill="x", pady=(6, 0))
            for txt, cmd in (("Ván mới", self.new_game), ("Đi lại", self.undo),
                             ("Lật bàn", self.flip), ("Mở thư mục ảnh", self.open_shots)):
                ttk.Button(r4, text=txt, command=cmd).pack(side="left", expand=True, fill="x", padx=2)

            lf = ttk.LabelFrame(right, text="Đọc màn hình (bàn cờ trên web)", padding=8)
            lf.pack(fill="x", pady=(8, 0))
            r7 = ttk.Frame(lf)
            r7.pack(fill="x")
            for txt, cmd in (("Tìm bàn cờ", self.screen_detect), ("Chọn vùng", self.screen_select),
                             ("Học quân", self.screen_learn), ("Đồng bộ lại", self.screen_resync)):
                ttk.Button(r7, text=txt, command=cmd).pack(side="left", expand=True, fill="x", padx=2)
            self.sdrag = tk.BooleanVar(value=False)
            ttk.Checkbutton(lf, text="Kéo thả quân (thay vì click 2 lần)", variable=self.sdrag).pack(anchor="w", pady=(4, 0))
            self.scr_lbl = ttk.Label(lf, text="", font=("Consolas", 8))
            self.scr_lbl.pack(anchor="w")

            lf = ttk.LabelFrame(right, text="Dữ liệu Hugging Face", padding=8)
            lf.pack(fill="x", pady=8)
            r5 = ttk.Frame(lf)
            r5.pack(fill="x")
            ttk.Label(r5, text="Số ván:").pack(side="left")
            self.n_games = tk.StringVar(value="20000")
            ttk.Entry(r5, textvariable=self.n_games, width=8).pack(side="left", padx=4)
            ttk.Button(r5, text="Tạo opening book", command=self.build_book).pack(side="left", padx=4)
            r6 = ttk.Frame(lf)
            r6.pack(fill="x", pady=(4, 0))
            ttk.Label(r6, text="Số thế cờ:").pack(side="left")
            self.n_pos = tk.StringVar(value="100000")
            ttk.Entry(r6, textvariable=self.n_pos, width=8).pack(side="left", padx=4)
            ttk.Button(r6, text="Huấn luyện NN", command=self.train_nn).pack(side="left", padx=4)
            ttk.Button(r6, text="Dừng", command=self.bg_stop.set).pack(side="left")

            lf = ttk.LabelFrame(right, text="Engine", padding=8)
            lf.pack(fill="x")
            self.info_lbl = ttk.Label(lf, text="—", justify="left", font=("Consolas", 9))
            self.info_lbl.pack(anchor="w")

            lf = ttk.LabelFrame(right, text="Nước đi / Nhật ký", padding=6)
            lf.pack(fill="both", expand=True, pady=(8, 0))
            self.moves_txt = tk.Text(lf, height=3, width=46, bg="#15181c", fg=FG, font=("Consolas", 9),
                                     wrap="word", relief="flat")
            self.moves_txt.pack(fill="x")
            self.log_txt = tk.Text(lf, height=6, width=46, bg="#15181c", fg="#9fb3c8", font=("Consolas", 8),
                                   wrap="word", relief="flat")
            self.log_txt.pack(fill="both", expand=True, pady=(4, 0))

        def update_elo_label(self):
            p = elo_params(self.elo.get())
            self.elo_lbl.config(text=f"Elo {p['elo']}: {p['movetime']}s/nước, độ sâu ≤ {p['max_depth']}, "
                                     f"sai số {int(p['blunder_prob'] * 100)}%")

        def _setup_hotkeys(self):
            """Phím tắt toàn cục (kể cả khi cửa sổ không được chọn) nếu có pynput; nếu không thì phím trong cửa sổ."""
            self.global_keys = False
            try:
                from pynput import keyboard as pk
                mapping = {pk.Key.f1: "F1", pk.Key.f2: "F2", pk.Key.f3: "F3"}

                def on_press(key):
                    if key in mapping:
                        self.q.put(("hotkey", mapping[key]))
                self.listener = pk.Listener(on_press=on_press)
                self.listener.daemon = True
                self.listener.start()
                self.global_keys = True
                self.log("Phím tắt F1/F2/F3 hoạt động toàn cục (pynput).")
            except Exception:
                self.root.bind_all("<F1>", lambda e: self.hk_start())
                self.root.bind_all("<F2>", lambda e: self.hk_pause())
                self.root.bind_all("<F3>", lambda e: self.quit())
                self.log("Phím tắt F1/F2/F3 hoạt động khi cửa sổ đang được chọn.")

        # ------------------------------------------------------------- tiện ích
        def log(self, msg):
            ts = datetime.datetime.now().strftime("%H:%M:%S")
            self.log_txt.insert("end", f"[{ts}] {msg}\n")
            self.log_txt.see("end")

        def set_status(self, msg):
            self.status.config(text=msg)

        def is_bot_turn(self):
            if self.mode.get() == "bvb":
                return True
            human = chess.WHITE if self.human_color.get() == "white" else chess.BLACK
            return self.board.turn != human

        # ------------------------------------------------------------- vẽ
        def sq_xy(self, s):
            f, r = chess.square_file(s), chess.square_rank(s)
            if self.flipped:
                return (7 - f) * SQ, r * SQ
            return f * SQ, (7 - r) * SQ

        def redraw(self):
            c = self.canvas
            c.delete("all")
            last = self.board.peek() if self.board.move_stack else None
            check_sq = self.board.king(self.board.turn) if self.board.is_check() else None
            targets = set()
            if self.selected is not None:
                targets = {m.to_square for m in self.board.legal_moves if m.from_square == self.selected}
            for s in chess.SQUARES:
                x, y = self.sq_xy(s)
                col = LIGHT if (chess.square_file(s) + chess.square_rank(s)) % 2 else DARK
                if last and s in (last.from_square, last.to_square):
                    col = LAST
                if s == self.selected:
                    col = SEL
                if s == check_sq:
                    col = CHECK
                c.create_rectangle(x, y, x + SQ, y + SQ, fill=col, width=0)
                p = self.board.piece_at(s)
                cx, cy = x + SQ / 2, y + SQ / 2 + 2
                if p and self.piece_font:
                    if p.color == chess.WHITE:
                        c.create_text(cx, cy, text=GLYPH_FILLED[p.piece_type], font=self.piece_font, fill="#ffffff")
                        c.create_text(cx, cy, text=GLYPH_OUTLINE[p.piece_type], font=self.piece_font, fill="#202020")
                    else:
                        c.create_text(cx, cy, text=GLYPH_FILLED[p.piece_type], font=self.piece_font, fill="#111111")
                elif p:
                    rr = SQ * 0.38
                    white = p.color == chess.WHITE
                    c.create_oval(cx - rr, cy - 2 - rr, cx + rr, cy - 2 + rr, fill="#f5f5f5" if white else "#1e1e1e",
                                  outline="#3c3c3c", width=2)
                    c.create_text(cx, cy - 2, text=p.symbol().upper(), font=("Helvetica", int(SQ * 0.32), "bold"),
                                  fill="#141414" if white else "#f0f0f0")
                if s in targets:
                    if p:
                        c.create_oval(x + 3, y + 3, x + SQ - 3, y + SQ - 3, outline="#3a6b35", width=4)
                    else:
                        c.create_oval(cx - 9, cy - 11, cx + 9, cy + 7, fill="#3a6b35", width=0)
            # toạ độ
            for i in range(8):
                f = 7 - i if self.flipped else i
                r = i if self.flipped else 7 - i
                c.create_text(i * SQ + SQ - 6, 8 * SQ - 8, text="abcdefgh"[f], font=("Segoe UI", 8, "bold"), fill="#5a4636")
                c.create_text(6, i * SQ + 9, text=str(r + 1), font=("Segoe UI", 8, "bold"), fill="#5a4636")

        def draw_eval_bar(self, cp_white):
            w = SQ * 8
            p = 1 / (1 + math.exp(-cp_white / 300))      # xác suất thắng xấp xỉ
            if self.flipped:
                p = 1 - p
            self.eval_bar.delete("all")
            self.eval_bar.create_rectangle(0, 0, w * p, 14, fill="#f2f2f2" if not self.flipped else "#222", width=0)
            self.eval_bar.create_rectangle(w * p, 0, w, 14, fill="#222" if not self.flipped else "#f2f2f2", width=0)

        def update_moves(self):
            b = chess.Board()
            parts = []
            for i, m in enumerate(self.board.move_stack):
                san = b.san(m)
                parts.append(f"{i // 2 + 1}. {san}" if i % 2 == 0 else san)
                b.push(m)
            self.moves_txt.delete("1.0", "end")
            self.moves_txt.insert("end", " ".join(parts))
            self.moves_txt.see("end")

        # ------------------------------------------------------------- phím tắt
        def hk_start(self):
            if self.mode.get() == "screen":
                self.screen_start()
                return
            if self.board.is_game_over(claim_draw=True):
                self.new_game()
            if not self.started:
                self.started, self.paused = True, False
                self.start_shot_session()
                self.log("Bắt đầu ván cờ.")
            elif self.paused:
                self.paused = False
                self.log("Tiếp tục.")
            self.update_turn_status()
            self.maybe_bot()

        def hk_pause(self):
            if self.screen_running():
                if not self.sbot.paused:
                    self.sbot.paused = True
                    self.sbot.gen += 1
                    self.engine.stop()
                    self.set_status("⏸ Bot màn hình đã tạm dừng — bấm F1 để tiếp tục")
                    self.log("Tạm dừng bot màn hình.")
                return
            if self.started and not self.paused:
                self.paused = True
                self.cancel_thinking()
                self.set_status("⏸ Đã tạm dừng — bấm F1 để tiếp tục")
                self.log("Tạm dừng.")

        def quit(self):
            if self.sbot:
                self.sbot.stop()
            self.cancel_thinking()
            self.bg_stop.set()
            try:
                if getattr(self, "listener", None):
                    self.listener.stop()
            except Exception:
                pass
            self.root.destroy()

        # ------------------------------------------------------------- ván cờ
        def new_game(self):
            if self.screen_running():
                self.sbot.stop()
            self.cancel_thinking()
            self.board = chess.Board()
            self.engine.new_game()
            self.selected = None
            self.started, self.paused = False, False
            self.flipped = self.human_color.get() == "black"
            self.redraw()
            self.update_moves()
            self.draw_eval_bar(0)
            self.set_status("Ván mới — bấm F1 để bắt đầu")

        def undo(self):
            if self.mode.get() == "bvb" or not self.board.move_stack:
                return
            self.cancel_thinking()
            self.board.pop()
            human = chess.WHITE if self.human_color.get() == "white" else chess.BLACK
            if self.board.move_stack and self.board.turn != human:
                self.board.pop()
            self.selected = None
            self.redraw()
            self.update_moves()
            self.update_turn_status()
            self.maybe_bot()

        def flip(self):
            self.flipped = not self.flipped
            self.redraw()

        def on_color(self):
            self.flipped = self.human_color.get() == "black"
            self.redraw()
            self.maybe_bot()

        def update_turn_status(self):
            if not self.started:
                return
            if self.board.is_game_over():
                return
            if self.paused:
                self.set_status("⏸ Đã tạm dừng — bấm F1 để tiếp tục")
                return
            side = "Trắng" if self.board.turn == chess.WHITE else "Đen"
            if self.is_bot_turn():
                self.set_status(f"🤖 Máy ({side}) đang suy nghĩ…")
            else:
                self.set_status(f"🙂 Lượt của bạn ({side})")

        def on_click(self, ev):
            if self.mode.get() == "screen":
                return
            if not self.started or self.paused or self.thinking or self.is_bot_turn() or self.board.is_game_over():
                return
            f, r = int(ev.x // SQ), 7 - int(ev.y // SQ)
            if self.flipped:
                f, r = 7 - f, 7 - r
            if not (0 <= f < 8 and 0 <= r < 8):
                return
            s = chess.square(f, r)
            if self.selected is not None:
                cands = [m for m in self.board.legal_moves if m.from_square == self.selected and m.to_square == s]
                if cands:
                    mv = cands[0]
                    if len(cands) > 1 or mv.promotion:
                        promo = self.ask_promotion()
                        if promo is None:
                            return
                        mv = chess.Move(self.selected, s, promotion=promo)
                    self.selected = None
                    self.apply_move(mv, by="Bạn")
                    return
            p = self.board.piece_at(s)
            self.selected = s if (p and p.color == self.board.turn) else None
            self.redraw()

        def ask_promotion(self):
            win = tk.Toplevel(self.root)
            win.title("Phong cấp")
            win.configure(bg=PANEL)
            win.transient(self.root)
            win.grab_set()
            res = {"pt": None}
            for pt, name in ((chess.QUEEN, "Hậu"), (chess.ROOK, "Xe"), (chess.BISHOP, "Tượng"), (chess.KNIGHT, "Mã")):
                ttk.Button(win, text=f"{GLYPH_OUTLINE[pt]} {name}",
                           command=lambda p=pt: (res.update(pt=p), win.destroy())).pack(fill="x", padx=10, pady=3)
            self.root.wait_window(win)
            return res["pt"]

        def apply_move(self, mv, by, info=None):
            san = self.board.san(mv)
            self.board.push(mv)
            self.redraw()
            self.update_moves()
            extra = ""
            if info and info.get("source"):
                extra = f" [{info['source']}]"
            self.log(f"{by}: {san}{extra}")
            if self.do_shots.get():
                n = len(self.board.move_stack)
                # đợi màn hình vẽ xong rồi mới chụp
                self.root.after(60, lambda b=self.board.copy(), n=n, s=san, w=by: self.capture(b, n, s, w))
            if self.board.is_game_over(claim_draw=True):
                self.game_over()
                return
            self.update_turn_status()
            self.maybe_bot()

        def game_over(self):
            o = self.board.outcome(claim_draw=True)
            if o.winner is None:
                txt = f"Hòa ({o.termination.name.lower()})"
            else:
                txt = ("Trắng" if o.winner else "Đen") + " thắng"
                if o.termination == chess.Termination.CHECKMATE:
                    txt += " (chiếu hết)"
            self.set_status(f"🏁 Kết thúc: {txt} — {self.board.result(claim_draw=True)}")
            self.log(f"Kết thúc ván: {txt}")
            self.started = False

        # ------------------------------------------------------------- bot
        def maybe_bot(self):
            if self.mode.get() == "screen":
                return
            if (not self.started or self.paused or self.thinking or self.board.is_game_over()
                    or not self.is_bot_turn()):
                return
            self.thinking = True
            self.update_turn_status()
            gen = self.gen
            board = self.board.copy()
            elo = self.elo.get()
            use_book = self.use_book.get()
            use_nn = self.use_nn.get() and self.engine.nn is not None
            min_delay = 0.45 if self.mode.get() == "bvb" else 0.3   # đọc biến Tk ở luồng chính

            def info_cb(d):
                self.q.put(("info", gen, d, board.turn))

            def work():
                t0 = time.perf_counter()
                with self.engine_lock:          # đợi luồng cũ (đã bị dừng) thoát hẳn
                    if gen != self.gen:
                        return
                    self.engine.use_nn = use_nn
                    try:
                        mv, info = self.engine.choose_move(board, elo, use_book, info_cb)
                    except Exception as e:
                        self.q.put(("error", gen, repr(e)))
                        return
                # trễ tối thiểu: kịp chụp ảnh nước trước + người xem kịp theo dõi
                time.sleep(max(0.0, min_delay - (time.perf_counter() - t0)))
                self.q.put(("move", gen, mv, info))
            threading.Thread(target=work, daemon=True).start()

        def cancel_thinking(self):
            self.gen += 1
            if self.thinking:
                self.engine.stop()
            self.thinking = False

        # ------------------------------------------------------------- chụp ảnh (NumPy + OpenCV)
        def start_shot_session(self):
            stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            self.shot_dir = os.path.join(SHOT_DIR, f"game_{stamp}")
            os.makedirs(self.shot_dir, exist_ok=True)
            self.capture(self.board.copy(), len(self.board.move_stack), "start", "Bắt đầu")

        def grab_canvas(self):
            """Chụp vùng bàn cờ trên màn hình -> mảng NumPy BGR."""
            from PIL import ImageGrab
            self.root.update_idletasks()
            x, y = self.canvas.winfo_rootx(), self.canvas.winfo_rooty()
            w, h = self.canvas.winfo_width(), self.canvas.winfo_height()
            try:
                pil = ImageGrab.grab(bbox=(x, y, x + w, y + h), all_screens=True)
            except TypeError:
                pil = ImageGrab.grab(bbox=(x, y, x + w, y + h))
            arr = np.asarray(pil.convert("RGB"))
            return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)

        def capture(self, board, ply, san, who, img=None):
            if cv2 is None:
                self.log("Chưa cài opencv-python nên không chụp được ảnh.")
                return
            if self.shot_dir is None:
                stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                self.shot_dir = os.path.join(SHOT_DIR, f"game_{stamp}")
                os.makedirs(self.shot_dir, exist_ok=True)
            last = board.peek() if board.move_stack else None
            if img is None and self.shot_src.get() == "screen" and self.root.state() != "iconic":
                try:
                    img = self.grab_canvas()
                    # ảnh gần như một màu (cửa sổ bị che/thu nhỏ) -> dùng ảnh vẽ
                    if img is None or img.size == 0 or float(img.std()) < 3:
                        img = None
                except Exception as e:
                    self.log(f"Không chụp được màn hình ({e}); dùng ảnh vẽ OpenCV.")
                    img = None
            if img is None:
                img = render_board_cv2(board, last, self.flipped)

            # chú thích phía dưới ảnh
            if img.shape[1] < 400:                  # ảnh bàn cờ nhỏ -> phóng to cho dễ xem
                f = 400 / img.shape[1]
                img = cv2.resize(img, None, fx=f, fy=f, interpolation=cv2.INTER_CUBIC)
            h, w = img.shape[:2]
            banner = np.full((44, w, 3), (35, 31, 28), np.uint8)
            move_no = (ply + 1) // 2
            txt = f"Ply {ply} | {who}: {san}" if ply else "Vi tri ban dau"
            cv2.putText(banner, _ascii(txt), (8, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (230, 230, 230), 1, cv2.LINE_AA)
            out = np.vstack([img, banner])
            safe = re.sub(r"[^A-Za-z0-9+#=\-]", "", san) or "pos"
            path = os.path.join(self.shot_dir, f"{ply:03d}_{move_no:02d}_{safe}.png")
            if imwrite_unicode(path, out):
                self.shot_count += 1

        def open_shots(self):
            d = self.shot_dir or SHOT_DIR
            os.makedirs(d, exist_ok=True)
            try:
                if sys.platform == "win32":
                    os.startfile(d)
                elif sys.platform == "darwin":
                    os.system(f'open "{d}"')
                else:
                    os.system(f'xdg-open "{d}" >/dev/null 2>&1 &')
            except Exception as e:
                messagebox.showinfo("Ảnh chụp", f"Ảnh nằm ở:\n{d}\n({e})")

        # ------------------------------------------------------------- Hugging Face (chạy nền)
        def _bg(self, fn, name):
            if self.bg_busy:
                self.log("Đang có một tác vụ dữ liệu chạy, vui lòng đợi.")
                return
            try:
                import datasets  # noqa: F401
            except ImportError:
                self.log("Chưa cài thư viện 'datasets'. Chạy: pip install datasets")
                return
            self.bg_busy = True
            self.bg_stop.clear()

            def run():
                try:
                    fn()
                except Exception as e:
                    self.q.put(("log", f"[{name}] lỗi: {e}"))
                finally:
                    self.q.put(("bg_done", name))
            threading.Thread(target=run, daemon=True).start()

        def build_book(self, auto=False):
            try:
                n = int(self.n_games.get())
            except ValueError:
                n = 20000
            if auto:
                n = min(n, 5000)
                self.log("Đang tự tạo opening book nhỏ từ Hugging Face ở nền (bạn vẫn chơi bình thường)…")
            prog = lambda s: self.q.put(("log", s))

            def job():
                book = OpeningBook.__new__(OpeningBook)
                book.path, book.data, book.source = BOOK_PATH, {}, "none"
                used = book.build_from_hf(n_games=n, progress=prog, stop=self.bg_stop)
                if used and book.data:
                    self.engine.book = book
            self._bg(job, "Book")

        def train_nn(self):
            try:
                n = int(self.n_pos.get())
            except ValueError:
                n = 100000
            prog = lambda s: self.q.put(("log", s))

            def job():
                X, Y = NNEval.collect_from_hf(n, progress=prog, stop=self.bg_stop)
                prog(f"[NN] bắt đầu huấn luyện trên {len(X)} thế cờ")
                nn = NNEval(hidden=64)
                nn.train(X, Y, epochs=4, progress=prog, stop=self.bg_stop)
                nn.save()
                self.engine.nn = nn
                prog(f"[NN] đã lưu {NN_PATH}. Tick 'Dùng mạng neural' để bật.")
            self._bg(job, "NN")

        # ------------------------------------------------------------- bot trên màn hình (web)
        def screen_running(self):
            return self.sbot is not None and self.sbot.thread is not None and self.sbot.thread.is_alive()

        def update_screen_label(self):
            reg = "chưa có" if not self.sregion else "x={:.0f} y={:.0f} {:.0f}x{:.0f}".format(*self.sregion)
            tpl = "đã học" if self.sclf is not None else "chưa học"
            self.scr_lbl.config(text=f"Vùng bàn cờ: {reg}   |   Mẫu quân: {tpl}")

        def _save_region(self):
            os.makedirs(DATA_DIR, exist_ok=True)
            with open(SCREEN_CFG, "w", encoding="utf-8") as f:
                json.dump({"region": list(self.sregion)}, f)
            self.update_screen_label()

        def _app_rect(self):
            self.root.update_idletasks()
            return (self.root.winfo_rootx(), self.root.winfo_rooty(),
                    self.root.winfo_width(), self.root.winfo_height())

        def screen_detect(self):
            """Tự tìm bàn cờ trên toàn màn hình (che cửa sổ của chính app vì app cũng có bàn cờ)."""
            if cv2 is None:
                self.log("Cần cài opencv-python.")
                return False
            try:
                img, (ox, oy) = self.grabber.grab(None)
            except Exception as e:
                self.log(f"Không chụp được màn hình: {e}")
                return False
            img = img.copy()
            ax, ay, aw, ah = self._app_rect()
            x0, y0 = ax - ox, ay - oy
            img[max(0, y0 - 45):max(0, y0 + ah + 10), max(0, x0 - 10):max(0, x0 + aw + 10)] = 0
            r = detect_board(img)
            if r is None:
                self.log("Không tự tìm thấy bàn cờ. Hãy để bàn cờ hiện rõ (không bị che) hoặc bấm 'Chọn vùng'.")
                return False
            self.sregion = (r[0] + ox, r[1] + oy, r[2], r[3])
            self._save_region()
            self.log("Đã tìm thấy bàn cờ: x={:.0f} y={:.0f} rộng {:.0f}px.".format(*self.sregion[:3]))
            return True

        def screen_select(self):
            """Kéo chuột khoanh vùng bàn cờ trên một lớp phủ trong suốt toàn màn hình."""
            ov = tk.Toplevel(self.root)
            ov.attributes("-fullscreen", True)
            try:
                ov.attributes("-alpha", 0.3)
                ov.attributes("-topmost", True)
            except tk.TclError:
                pass
            cv_ = tk.Canvas(ov, bg="black", highlightthickness=0, cursor="crosshair")
            cv_.pack(fill="both", expand=True)
            cv_.create_text(ov.winfo_screenwidth() // 2, 40, fill="white", font=("Segoe UI", 18, "bold"),
                            text="Kéo chuột bao quanh ĐÚNG mép bàn cờ 8x8  (Esc để huỷ)")
            st = {}

            def press(e):
                st.update(x=e.x_root, y=e.y_root, cx=e.x, cy=e.y)
                st["rect"] = cv_.create_rectangle(e.x, e.y, e.x, e.y, outline="red", width=3)

            def motion(e):
                if "rect" in st:
                    cv_.coords(st["rect"], st["cx"], st["cy"], e.x, e.y)

            def release(e):
                if "x" not in st:
                    return
                x0, y0 = min(st["x"], e.x_root), min(st["y"], e.y_root)
                w, h = abs(e.x_root - st["x"]), abs(e.y_root - st["y"])
                ov.destroy()
                if min(w, h) < 80:
                    self.log("Vùng chọn quá nhỏ.")
                    return
                self.sregion = (float(x0), float(y0), float(w), float(h))
                self._save_region()
                try:
                    img, _ = self.grabber.grab(self.sregion)
                    sc = checker_score(img)
                    self.log(f"Đã chọn vùng bàn cờ ({w}x{h}px), độ khớp hoạ tiết ô cờ {sc:.0%}.")
                    if sc < 0.8:
                        self.log("Cảnh báo: vùng chọn có vẻ chưa đúng mép bàn cờ.")
                except Exception:
                    pass

            cv_.bind("<ButtonPress-1>", press)
            cv_.bind("<B1-Motion>", motion)
            cv_.bind("<ButtonRelease-1>", release)
            ov.bind("<Escape>", lambda e: ov.destroy())
            ov.focus_force()

        def screen_learn(self):
            """Học hình dạng 12 loại quân từ bàn cờ trên màn hình ở THẾ BAN ĐẦU."""
            if self.sregion is None and not self.screen_detect():
                return False
            img, _ = self.grabber.grab(self.sregion)
            clf = PieceClassifier()
            try:
                flipped = clf.fit_from_start(img)
            except ValueError as e:
                self.log(f"{e} Hãy mở một ván mới trên web rồi bấm 'Học quân' lại.")
                return False
            pos, _ = clf.predict_placement(img, flipped)
            if pos != START_PLACEMENT:
                self.log("Học xong nhưng tự kiểm tra chưa khớp 100% — nên chọn lại vùng bàn cờ cho sát mép.")
            clf.save()
            self.sclf = clf
            os.makedirs(SHOT_DIR, exist_ok=True)
            imwrite_unicode(os.path.join(SHOT_DIR, "hoc_quan_the_ban_dau.png"), img)
            self.log(f"Đã học {len(clf.X)} mẫu quân từ màn hình (bên dưới là "
                     f"{'Đen' if flipped else 'Trắng'}). Lưu tại {SCREEN_TPL}")
            self.update_screen_label()
            return True

        def screen_resync(self):
            if self.screen_running():
                self.sbot.resync = True
                self.sbot.paused = False
                self.log("Đọc lại thế cờ từ màn hình…")
            else:
                self.log("Bot màn hình chưa chạy — bấm F1 để bắt đầu.")

        def screen_start(self):
            if self.screen_running():
                if self.sbot.paused:
                    self.sbot.paused = False
                    self.set_status("🖥 Bot màn hình tiếp tục…")
                    self.log("Tiếp tục bot màn hình.")
                return
            if cv2 is None:
                self.log("Cần cài opencv-python.")
                return
            ok_region = False
            if self.sregion is not None:
                try:
                    ok_region = checker_score(self.grabber.grab(self.sregion)[0]) >= 0.8
                except Exception:
                    ok_region = False
            if not ok_region and not self.screen_detect():
                return
            if self.sclf is None and not self.screen_learn():
                return
            try:
                mouse = MouseController()
            except Exception as e:
                self.log(f"Không điều khiển được chuột (cần 'pip install pyautogui'): {e}")
                return
            ax, ay, aw, ah = self._app_rect()
            x, y, w, h = self.sregion
            if x < ax + aw and ax < x + w and y < ay + ah and ay < y + h:
                self.log("Cảnh báo: cửa sổ app đang che bàn cờ — hãy kéo app sang bên cạnh, nếu không bot sẽ click nhầm.")
            if not self.global_keys:
                self.log("Cảnh báo: chưa có pynput nên F1/F2/F3 chỉ nhận khi cửa sổ app đang được chọn "
                         "(khi bạn ở trình duyệt sẽ không có tác dụng). Cài: pip install pynput")
            stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            self.shot_dir = os.path.join(SHOT_DIR, f"screen_{stamp}")
            os.makedirs(self.shot_dir, exist_ok=True)
            self.cancel_thinking()
            self.started, self.paused = True, False
            emit = lambda kind, *a: self.q.put((kind,) + a)
            self.sbot = ScreenBot(self.engine, self.engine_lock, self.grabber, mouse, self.sclf,
                                  self.sregion, emit, self.settings)
            self.sbot.start()
            self.set_status("🖥 Bot đang đọc bàn cờ trên màn hình…")
            self.log("Bắt đầu bot màn hình. Đưa chuột vào góc màn hình để dừng khẩn cấp.")

        # ------------------------------------------------------------- vòng lặp sự kiện
        def poll(self):
            try:
                while True:
                    item = self.q.get_nowait()
                    kind = item[0]
                    if kind == "hotkey":
                        {"F1": self.hk_start, "F2": self.hk_pause, "F3": self.quit}[item[1]]()
                        if item[1] == "F3":
                            return
                    elif kind in ("info", "sinfo"):
                        if kind == "info":
                            _, gen, d, turn = item
                            if gen != self.gen:
                                continue
                        else:
                            _, d, turn = item
                        sc = d["score"]
                        white_cp = sc if turn == chess.WHITE else -sc
                        if abs(sc) > MATE_BOUND:
                            mi = (MATE - abs(sc) + 1) // 2
                            sc_txt = f"#{mi if white_cp > 0 else -mi}"
                        else:
                            sc_txt = f"{white_cp / 100:+.2f}"
                        b = self.board.copy()
                        try:
                            pv = b.variation_san(d["pv"][:8]) if d["pv"] else ""
                        except Exception:
                            pv = ""
                        self.info_lbl.config(text=f"độ sâu {d['depth']:>2}   đánh giá {sc_txt}\n"
                                                  f"nodes {d['nodes']:,}   {d['nps']:,} n/s\nPV: {pv}")
                        self.draw_eval_bar(max(-3000, min(3000, white_cp)))
                    elif kind == "move":
                        _, gen, mv, info = item
                        if gen != self.gen:
                            continue
                        self.thinking = False
                        if mv is not None and mv in self.board.legal_moves and self.started and not self.paused:
                            side = "Máy-Trắng" if self.board.turn == chess.WHITE else "Máy-Đen"
                            self.apply_move(mv, by=side if self.mode.get() == "bvb" else "Máy", info=info)
                    elif kind == "error":
                        _, gen, msg = item
                        if gen == self.gen:
                            self.thinking = False
                            self.log(f"Lỗi engine: {msg}")
                    elif kind == "log":
                        self.log(item[1])
                    elif kind == "sboard":
                        _, board, flipped, img = item
                        self.board, self.flipped, self.selected = board, flipped, None
                        self.redraw()
                        self.update_moves()
                        if self.do_shots.get():
                            self.capture(board, len(board.move_stack), "start", "Bat dau", img=img)
                    elif kind == "smove":
                        _, board, san, who, img, info = item
                        self.board = board
                        self.redraw()
                        self.update_moves()
                        src = f" [{info['source']}]" if info and info.get("source") else ""
                        self.log(f"{who}: {san}{src}")
                        if self.do_shots.get():
                            self.capture(board, len(board.move_stack), san, who, img=img)
                        if not board.is_game_over(claim_draw=True):
                            mine = self.sbot is not None and board.turn == self.sbot.bot_color
                            self.set_status("🤖 Bot đang suy nghĩ…" if mine else "👀 Đang chờ đối thủ đi…")
                    elif kind == "sgameover":
                        self.board = item[1]
                        self.redraw()
                        self.started = True
                        self.game_over()
                    elif kind == "spaused":
                        self.set_status("⏸ Bot màn hình tạm dừng — bấm 'Đồng bộ lại' rồi F1")
                    elif kind == "sstopped":
                        if not self.board.is_game_over(claim_draw=True):
                            self.set_status("Bot màn hình đã dừng — bấm F1 để chạy lại")
                        self.started = False
                    elif kind == "bg_done":
                        self.bg_busy = False
                        self.log(f"[{item[1]}] hoàn tất. Book: {len(self.engine.book)} thế cờ "
                                 f"({self.engine.book.source}).")
            except queue.Empty:
                pass
            # cài đặt cho luồng bot màn hình (chỉ luồng chính được đọc biến Tkinter)
            self.settings.update(elo=self.elo.get(), use_book=self.use_book.get(),
                                 use_nn=self.use_nn.get(), drag=self.sdrag.get())
            self.root.after(40, self.poll)

    root = tk.Tk()
    root.minsize(1000, 640)
    App(root)
    root.mainloop()


def _ascii(s):
    """OpenCV putText chỉ vẽ được ASCII -> bỏ dấu tiếng Việt."""
    import unicodedata
    s = s.replace("đ", "d").replace("Đ", "D")
    return unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()


# ============================================================================
# Công cụ dòng lệnh: bench, match (bản mới đấu bản cũ)
# ============================================================================
BENCH_FENS = [
    chess.STARTING_FEN,
    "r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3",
    "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
    "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
    "r1bq1rk1/pp2bppp/2n1pn2/3p4/2PP4/2N1PN2/PP1B1PPP/R2QKB1R w KQ - 0 8",
]


def bench(depth=5):
    eng = Engine()
    total_n, t0 = 0, time.perf_counter()
    for fen in BENCH_FENS:
        eng.new_game()
        b = chess.Board(fen)
        mv, sc, d = eng.search(b, movetime=None, max_depth=depth)
        total_n += eng.nodes
        print(f"{fen[:40]:<42} best={b.san(mv):<6} score={sc:+5d} depth={d} nodes={eng.nodes}")
    dt = time.perf_counter() - t0
    print(f"Tổng: {total_n} nodes trong {dt:.1f}s -> {int(total_n / dt)} nodes/s")


def match(games, elo_a, elo_b, nn_a=False, nn_b=False):
    """Cho cấu hình A đấu cấu hình B (đổi màu luân phiên) để kiểm tra thay đổi có giúp bot mạnh hơn."""
    a, b = Engine(), Engine()
    a.use_nn, b.use_nn = nn_a and a.nn is not None, nn_b and b.nn is not None
    score_a = 0.0
    for g in range(games):
        board = chess.Board()
        a.new_game()
        b.new_game()
        white_is_a = g % 2 == 0
        while not board.is_game_over(claim_draw=True) and board.fullmove_number < 150:
            a_turn = (board.turn == chess.WHITE) == white_is_a
            eng, elo = (a, elo_a) if a_turn else (b, elo_b)
            mv, _ = eng.choose_move(board, elo)
            board.push(mv)
        res = board.result(claim_draw=True)
        if res == "1-0":
            score_a += 1 if white_is_a else 0
        elif res == "0-1":
            score_a += 0 if white_is_a else 1
        else:
            score_a += 0.5
        print(f"Ván {g + 1}: {'A' if white_is_a else 'B'} cầm Trắng -> {res}   (A: {score_a}/{g + 1})", flush=True)
    pct = score_a / games
    if 0 < pct < 1:
        diff = -400 * math.log10(1 / pct - 1)
        print(f"A ghi {score_a}/{games} ({pct:.0%}) ≈ chênh {diff:+.0f} Elo so với B")
    else:
        print(f"A ghi {score_a}/{games}")


# ============================================================================
def main():
    ap = argparse.ArgumentParser(description="ChessAI - bot cờ vua")
    ap.add_argument("--uci", action="store_true", help="chạy ở chế độ UCI engine")
    ap.add_argument("--book", type=int, metavar="N", help="tạo opening book từ N ván trên Hugging Face")
    ap.add_argument("--month", default="2024-01", help="tháng dữ liệu Lichess cho --book (YYYY-MM)")
    ap.add_argument("--train", type=int, metavar="N", help="huấn luyện mạng đánh giá trên N thế cờ")
    ap.add_argument("--epochs", type=int, default=4)
    ap.add_argument("--bench", action="store_true")
    ap.add_argument("--match", type=int, metavar="GAMES")
    ap.add_argument("--elo-a", type=int, default=ELO_MAX)
    ap.add_argument("--elo-b", type=int, default=ELO_MAX)
    ap.add_argument("--nn-a", action="store_true")
    ap.add_argument("--nn-b", action="store_true")
    args = ap.parse_args()

    if args.uci:
        uci_loop()
    elif args.book:
        OpeningBook().build_from_hf(n_games=args.book, progress=print, year_month=args.month)
    elif args.train:
        X, Y = NNEval.collect_from_hf(args.train, progress=print)
        nn = NNEval()
        nn.train(X, Y, epochs=args.epochs, progress=print)
        nn.save()
        print("Đã lưu", NN_PATH)
    elif args.bench:
        bench()
    elif args.match:
        match(args.match, args.elo_a, args.elo_b, args.nn_a, args.nn_b)
    else:
        run_gui()


if __name__ == "__main__":
    main()
