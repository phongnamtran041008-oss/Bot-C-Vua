# ChessAI — bot cờ vua 1 file (Python)

## Chạy
- **Windows:** bấm đúp `start.bat` (lần đầu tự cài thư viện, cần Python 3.10+ có tick "Add to PATH").
- **macOS/Linux:** `chmod +x start.sh && ./start.sh`

## Phím tắt
| Phím | Tác dụng |
|---|---|
| F1 | Bắt đầu ván / tiếp tục sau khi tạm dừng |
| F2 | Tạm dừng (bot ngừng suy nghĩ, không nhận nước đi) |
| F3 | Thoát |

Có `pynput` thì phím tắt hoạt động cả khi cửa sổ không được chọn (macOS cần cấp quyền Accessibility).

## Tính năng
- Thanh trượt Elo 1300–2500: Elo cao → nghĩ lâu hơn, sâu hơn, ít "sai số" hơn. Đây là ánh xạ ước lượng, chưa hiệu chuẩn bằng thi đấu thật.
- Chế độ Người vs Máy (chọn Trắng/Đen) và Máy vs Máy.
- Ảnh bàn cờ sau mỗi nước lưu ở `screenshots/game_<thời gian>/` (PIL ImageGrab → NumPy → OpenCV, có dòng chú thích nước đi). Nếu cửa sổ bị che, chọn nguồn ảnh "Vẽ OpenCV".
- Engine: alpha-beta (PVS), iterative deepening, quiescence, transposition table (Zobrist), move ordering (TT, MVV-LVA, chiếu, killer, history), null-move, LMR, aspiration window.

## Bot trên màn hình (chơi trên trang web cờ)
1. Mở trang cờ và vào một ván **ở thế ban đầu**. Kéo cửa sổ ChessAI sang bên cạnh, **không được che bàn cờ**.
2. Trong app chọn **"Bot trên màn hình (web)"**, chỉnh Elo.
3. Bấm **F1**. Lần đầu, app tự tìm bàn cờ trên màn hình, học hình 12 loại quân từ thế ban đầu (lưu ở `data/screen_templates.npz`), rồi bắt đầu chơi.
   - Bot luôn cầm bên quân đang ở **phía dưới** bàn cờ trên màn hình.
   - Nếu bên dưới là Đen và Trắng đã đi 1 nước, bot vẫn nhận ra nước đó.
4. **F2** tạm dừng, **F1** chạy tiếp, **F3** thoát. Phím tắt vẫn có tác dụng khi bạn đang ở trình duyệt (cần `pynput`).
5. **Dừng khẩn cấp:** đưa chuột vào một góc màn hình.

Các nút trong khung "Đọc màn hình":
- **Tìm bàn cờ:** tự tìm lại khi bạn cuộn trang hoặc di chuyển cửa sổ trình duyệt.
- **Chọn vùng:** tự kéo khung quanh bàn cờ nếu tìm tự động thất bại (ví dụ ô có vân gỗ).
- **Học quân:** học lại khi bạn đổi bộ quân hoặc màu bàn cờ. Cần thế ban đầu.
- **Đồng bộ lại:** đọc lại toàn bộ thế cờ nếu bot bị lệch.
- **Kéo thả quân:** dùng khi trang web không nhận kiểu click 2 lần.

Lưu ý khi dùng bot:
- Ảnh mỗi nước lưu ở `screenshots/screen_<thời gian>/`. Đây là ảnh chụp thật vùng bàn cờ trên màn hình.
- Không phóng to/thu nhỏ trang (zoom) hay cuộn trang khi bot đang chạy. Nếu lỡ làm, bấm F2 → "Tìm bàn cờ" → F1.
- Khi phong cấp, bot luôn chọn Hậu (click lần 2 vào ô phong cấp, đúng với giao diện chess.com/lichess).
- Chess.com và Lichess cấm dùng engine khi đấu với người thật, tài khoản sẽ bị khoá. Chỉ dùng khi đấu với máy của trang, trên bàn phân tích, hoặc với tài khoản bot chính thức.

## Dữ liệu Hugging Face
- **Opening book** từ `Lichess/standard-chess-games` (lọc ván Elo ≥ 1900, bỏ bullet). Lần đầu mở app tự tạo book nhỏ 5.000 ván ở nền; bấm "Tạo opening book" để làm lớn hơn. Lưu tại `data/opening_book.json`.
- **Mạng neural đánh giá** từ `Lichess/chess-position-evaluations` (điểm Stockfish). Bấm "Huấn luyện NN", rồi tick "Dùng mạng neural". Lưu tại `data/nn_eval.npz`.

Cả hai đọc dạng streaming nên không phải tải toàn bộ dataset.

## Dòng lệnh
```
python chess_ai.py --uci                 # engine UCI cho Arena / Cute Chess / lichess-bot
python chess_ai.py --book 50000          # tạo book từ 50k ván (--month 2024-06 để chọn tháng)
python chess_ai.py --train 300000        # huấn luyện mạng đánh giá
python chess_ai.py --bench               # đo tốc độ
python chess_ai.py --match 20 --nn-a     # bản dùng NN (A) đấu bản không dùng NN (B)
```
UCI hỗ trợ các option `UCI_LimitStrength`, `UCI_Elo`, `OwnBook`, `UseNN`.

## Endgame tablebase
Tải file Syzygy 3–5 quân (`.rtbw`, `.rtbz`) và đặt vào thư mục `syzygy/` cạnh `chess_ai.py`. Engine tự dùng khi Elo ≥ 1900.
