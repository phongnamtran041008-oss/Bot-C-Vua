@echo off
chcp 65001 >nul
title ChessAI
cd /d "%~dp0"

where python >nul 2>&1
if errorlevel 1 (
    echo [!] Chua cai Python. Hay cai Python 3.10+ tu https://www.python.org va tick "Add python.exe to PATH".
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo [*] Lan dau chay: dang tao moi truong ao, vui long doi...
    python -m venv .venv
    ".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
)
echo [*] Kiem tra thu vien...
".venv\Scripts\python.exe" -m pip install -q -r requirements.txt

".venv\Scripts\python.exe" chess_ai.py
if errorlevel 1 pause
