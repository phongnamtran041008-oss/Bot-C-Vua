#!/usr/bin/env bash
# Khởi động ChessAI trên macOS / Linux
cd "$(dirname "$0")"
if [ ! -x ".venv/bin/python" ]; then
    echo "[*] Lần đầu chạy: tạo môi trường ảo..."
    python3 -m venv .venv
    .venv/bin/python -m pip install --upgrade pip >/dev/null
fi
.venv/bin/python -m pip install -q -r requirements.txt
exec .venv/bin/python chess_ai.py "$@"
